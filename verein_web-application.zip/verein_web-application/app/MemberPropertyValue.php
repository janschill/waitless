<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\MemberProperty;

class MemberPropertyValue extends Model
{
    /**
     * @var array
     */
    protected $fillable = [
        'value',
        'member_property_id',
    ];

    /**
     * @var boolean
     */
    public $timestamps = false;

    public function memberProperty()
    {
        return $this->belongsTo(MemberProperty::class);
    }

    public function memberPropertyValueRelations()
    {
        return $this->hasMany(MemberPropertyValueRelation::class);
    }
}
