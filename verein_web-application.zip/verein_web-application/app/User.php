<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use VV\Verein\Club;
use VV\Verein\Notifications\ResetPassword;
use Illuminate\Support\Facades\Input;

class User extends Authenticatable
{
    use Notifiable;
    use SoftDeletes;

    /**
     * @var array
     */
    protected $dates = [
        'deleted_at'
    ];

    /**
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'avatar',
    ];

    /**
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function clubs()
    {
        return $this->belongsToMany(Club::class);
    }

    /**
     * Override Laravels default method to send the actual mail
     * with the reset link.
     * @see Illuminate\Auth\Passwords\CanResetPassword;
     *
     * @param string $token
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPassword($token));
    }

    /**
     * We need to get all notifications that are related to the club and
     * all notifications that are null, because they are related to all
     * clubs
     *
     * @param bool $withRead
     */
    public function getNotifications(bool $withRead = false)
    {
        $notifications = $this->unreadNotifications->whereIn('club_id', [\Session::get('active_club_id'), null]);

        if($withRead !== false) {
            $notifications = $notifications->merge(
                $this->readNotifications->whereIn('club_id', [\Session::get('active_club_id'), null])
            );
        }

        return $notifications;
    }

    public function setAvatarAttribute($value)
    {
        $filename = null;

        if (Input::hasFile('avatar')) {
            if ($this->avatar) {
                \Storage::disk('public')->delete('/uploads/' . $this->avatar);
            }

            $file = Input::file('avatar');
            $filename = md5($file->getClientOriginalName()) . '.' .$file->extension();
            $file->move(storage_path('app/public/uploads'), $filename);
        }

        $this->attributes['avatar'] = $filename;
    }
}
