<?php

namespace VV\Verein\Notifications;

class Generic extends AbstractNotification
{
    /**
     * @param string $headline
     * @param string $text
     * @param string $clubId
     */
    public function __construct(string $headline, string $text, int $clubId = null)
    {
        $this->headline = $headline;
        $this->text = $text;
        $this->club_id = $clubId;
    }

    /**
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'headline' => $this->headline,
            'text' => $this->text
        ];
    }
}
