<?php

namespace VV\Verein\Notifications\Channels;

use Illuminate\Notifications\Notification;

class DatabaseChannel extends \Illuminate\Notifications\Channels\DatabaseChannel
{
    /**
     * Override the parent DatabaseChannel to relate a notification with a club
     *
     * @param  mixed  $notifiable
     * @param  \Illuminate\Notifications\Notification  $notification
     * @return array
     */
    protected function buildPayload($notifiable, Notification $notification): array
    {
        return array_merge(
            parent::buildPayload($notifiable, $notification),
            [
                'club_id' => $notification->club_id ?? null
            ]
        );
    }
}
