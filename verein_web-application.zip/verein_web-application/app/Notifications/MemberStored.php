<?php

namespace VV\Verein\Notifications;

use VV\Verein\Member;

class MemberStored extends AbstractNotification
{
    /**
     * @param Member $member
     */
    public function __construct(Member $member)
    {
        $this->member = $member;
        $this->club_id = $member->club_id;
    }

    /**
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'headline' => 'Neues Mitglied',
            'text' => $this->member->memberable->name . ' ist eingetreten.'
        ];
    }
}
