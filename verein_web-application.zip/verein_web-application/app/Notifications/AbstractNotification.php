<?php

namespace VV\Verein\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use VV\Verein\Notifications\Channels\DatabaseChannel;

abstract class AbstractNotification extends Notification
{
    use Queueable;

    /**
     * @var null
     */
    public $club_id = null;

    /**
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return [DatabaseChannel::class];
    }
}
