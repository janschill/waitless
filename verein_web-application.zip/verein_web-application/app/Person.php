<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Member;

class Person extends Model
{
    const GENDER_FEMALE = 1;
    const GENDER_MALE = 2;
    const GENDER_UNKNOWN = 3;

    /**
     * @var string
     */
    protected $table = 'persons';

    /**
     * @var array
     */
    protected $dates = [
        'birthday',
    ];

    /**
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'nickname',
        'birthday',
        'gender',
    ];

    /**
     * @return string
     */
    public function getGenderAsString(): string
    {
        $gender = '';

        switch ($this->gender) {
            case self::GENDER_FEMALE:
                $gender = 'Weiblich';
                break;
            case self::GENDER_MALE:
                $gender = 'Männlich';
                break;
            case self::GENDER_UNKNOWN:
                $gender = 'Unbestimmt';
                break;
            default:
                $gender = 'Unbestimmt';
                break;
        }

        return $gender;
    }

    public function member()
    {
        return $this->morphOne(Member::class, 'memberable');
    }

    public function getNameAttribute(): string
    {
        return $this->first_name . ' ' . $this->last_name;
    }
}
