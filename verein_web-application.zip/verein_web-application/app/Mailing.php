<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Club;
use VV\Verein\Member;
use VV\Verein\Membership;

class Mailing extends Model
{
    /**
     * @var array
     */
    protected $fillable = [
        'subject',
        'text',
        'mail_type',
        'club_id',
    ];

    public function club()
    {
        return $this->belongsTo(Club::class);
    }
}
