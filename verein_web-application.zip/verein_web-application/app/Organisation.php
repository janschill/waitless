<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Member;

class Organisation extends Model
{
    /**
     * @var array
     */
    protected $dates = [
        'founded',
    ];

    /**
     * @var array
     */
    protected $fillable = [
        'name',
        'type',
        'contact_person',
        'founded',
    ];

    public function member()
    {
        return $this->morphOne(Member::class, 'memberable');
    }
}
