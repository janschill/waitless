<?php

namespace VV\Verein\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        Blade::directive('motto', function () {
            $motto = 'Digitalisiert durch visuellverstehen.';
            $privateToken = 'qzENQLGNRkWNWoSsqxD6';
            $projectId = '155'; // verein_verein_web-application
            $call = curl_init();

            curl_setopt($call, CURLOPT_URL, 'https://git.visuellverstehen.de/api/v4/projects/' . $projectId . '/repository/tags');
            curl_setopt($call, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($call, CURLOPT_HTTPHEADER, [
                'PRIVATE-TOKEN: ' . $privateToken
            ]);

            $tags = curl_exec($call);
            $tags = json_decode($tags);

            // Get motto from latest tag, which ist not a patch version (Everything except x.x.0)
            foreach ($tags as $tagKey => $tagValue) {
                if (substr($tagValue->name, -1) === '0') {
                    $motto = $tagValue->message;
                    break;
                }
            }

            curl_close($call);

            return $motto;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
