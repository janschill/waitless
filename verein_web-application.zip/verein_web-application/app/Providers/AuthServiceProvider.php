<?php

namespace VV\Verein\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use VV\Verein\Mailing;
use VV\Verein\Policies\MailingPolicy;
use VV\Verein\Member;
use VV\Verein\Policies\MemberPolicy;
use VV\Verein\MemberProperty;
use VV\Verein\Policies\MemberPropertyPolicy;
use VV\Verein\MembershipType;
use VV\Verein\Policies\MembershipTypePolicy;
use VV\Verein\MemberPropertyValue;
use VV\Verein\Policies\MemberPropertyValuePolicy;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * @var array
     */
    protected $policies = [
        Mailing::class => MailingPolicy::class,
        Member::class => MemberPolicy::class,
        MemberProperty::class => MemberPropertyPolicy::class,
        MemberPropertyValue::class => MemberPropertyValuePolicy::class,
        MembershipType::class => MembershipTypePolicy::class,
    ];

    public function boot()
    {
        $this->registerPolicies();
    }
}
