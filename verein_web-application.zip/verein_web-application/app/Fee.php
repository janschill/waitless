<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Member;
use VV\Verein\Membership;

class Fee extends Model
{
    /**
     * @var boolean
     */
    public $timestamps = false;

    /**
     * @var array
     */
    protected $fillable = [
        'amount',
        'paid_amount',
        'member_id',
        'membership_id',
        'start',
        'end',
    ];

    protected $dates = [
        'start',
        'end',
    ];

    public function member()
    {
        return $this->hasOne(Member::class);
    }

    public function membership()
    {
        return $this->belongsTo(Membership::class);
    }
}
