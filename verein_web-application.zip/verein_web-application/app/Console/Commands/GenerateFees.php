<?php

namespace VV\Verein\Console\Commands;

use \Carbon\Carbon;
use Illuminate\Console\Command;
use VV\Verein\Fee;
use VV\Verein\Membership;

class GenerateFees extends Command
{
    /**
     * @var string
     */
    protected $signature = 'verein:generatefees';

    /**
     * @var string
     */
    protected $description = 'Crawls all memberships that needs new fees';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $this->info('Start crawling for new fees …');

        /**
         * Find membershibs with the following contraints:
         * 1. Fees are outdated or has no fees
         * 2. Base monthly_fee is higher than 0 OR the member has an additional_fee
         */
        $memberships = Membership::with(
                [
                    'fees' => function($query) {
                        $query->orderBy('end', 'DESC');
                    }
                ]
            )
            ->whereHas('fees', function ($query) {
                $query->orderBy('end', 'DESC');
                $query->whereRaw('end < CURDATE()');
            })
            ->orWhereDoesntHave('fees')
            ->whereHas('membershipType', function ($query) {
                $query->where('monthly_fee', '>', 0);
                $query->orWhere('additional_fee', '>', 0);
            });

        $this->info('Found <comment>' . $memberships->count() . '</comment> memberships.');

        foreach ($memberships->get() as $membership) {
            $this->generateFee($membership);
        }
    }

    /**
     * @param Membership $membership
     */
    private function generateFee(Membership $membership)
    {
        $amount = ($membership->membershipType->monthly_fee + $membership->additional_fee) * round($membership->accountingPeriod->in_days / 30);
        $start = null;
        $end = null;

        if ($membership->fees->count() === 0) {
            $start = $membership->created_at;
            $end = $membership->created_at->addDays($membership->accountingPeriod->in_days);
        } else {
            $start = $membership->fees->sortByDesc('end')->first()->end;
            $end = $membership->fees->sortByDesc('end')->first()->end->addDays($membership->accountingPeriod->in_days);
        }

        Fee::create([
            'amount' => $amount,
            'paid_amount' => 0.00,
            'start' => $start,
            'end' => $end,
            'member_id' => $membership->member_id,
            'membership_id' => $membership->id
        ]);
    }
}
