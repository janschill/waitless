<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Club;
use VV\Verein\MemberPropertyValue;

class MemberProperty extends Model
{
    const TYPE_SELECT = 1;
    const TYPE_INPUT = 2;

    /**
     * @var array
     */
    protected $fillable = [
        'title',
        'club_id',
        'type',
    ];

    /**
     * @var boolean
     */
    public $timestamps = false;

    public function club()
    {
        return $this->belongsTo(Club::class);
    }

    public function memberPropertyValues()
    {
        return $this->hasMany(MemberPropertyValue::class);
    }
}
