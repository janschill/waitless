<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;

class AccountingPeriod extends Model
{
    /**
     * @var boolean
     */
    public $timestamps = false;

    /**
     * @var array
     */
    protected $fillable = [
        'title',
        'in_days',
    ];

    public function membershipTypes()
    {
        return $this->belongsToMany(MembershipTypes::class);
    }
}
