<?php

namespace VV\Verein\Services;

use \Auth;
use VV\Verein\Club;
use VV\Verein\Http\Requests\StoreClubRequest;
use VV\Verein\Notifications\Generic as GenericNotification;
use \Session;

class ClubService
{

    public function store(StoreClubRequest $request)
    {
        $club = Club::create($request->all());

        $user = Auth::user();
        $club->users()->attach($user);

        $user->notify(
            new GenericNotification(
                'Verein angelegt',
                $club->name . ' nutzt ab sofort ' . config('app.name') . '.'
            )
        );

        Session::put('active_club_id', $club->id);
    }
}
