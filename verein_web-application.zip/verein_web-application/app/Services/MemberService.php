<?php

namespace VV\Verein\Services;

class MemberService
{
}
