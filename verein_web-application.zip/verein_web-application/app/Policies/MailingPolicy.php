<?php

namespace VV\Verein\Policies;

use VV\Verein\User;
use VV\Verein\Mailing;
use Illuminate\Auth\Access\HandlesAuthorization;

class MailingPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param Mailing $mailing
     * @return bool
     */
    public function access(User $user, Mailing $mailing): bool
    {
        return $mailing->club->id === (int)\Session::get('active_club_id');
    }
}
