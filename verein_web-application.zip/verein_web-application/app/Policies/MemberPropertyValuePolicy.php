<?php

namespace VV\Verein\Policies;

use VV\Verein\User;
use VV\Verein\MemberPropertyValue;
use Illuminate\Auth\Access\HandlesAuthorization;

class MemberPropertyValuePolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param MemberPropertyValue $memberPropertyValue
     * @return bool
     */
    public function access(User $user, MemberPropertyValue $memberPropertyValue): bool
    {
        return $memberPropertyValue->memberProperty->club_id === (int)\Session::get('active_club_id');
    }
}
