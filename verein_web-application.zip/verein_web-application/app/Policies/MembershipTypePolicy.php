<?php

namespace VV\Verein\Policies;

use VV\Verein\User;
use VV\Verein\MembershipType;
use Illuminate\Auth\Access\HandlesAuthorization;

class MembershipTypePolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param MembershipType $membershipType
     * @return bool
     */
    public function access(User $user, MembershipType $membershipType): bool
    {
        return $membershipType->club_id === (int)\Session::get('active_club_id');
    }
}
