<?php

namespace VV\Verein\Policies;

use VV\Verein\User;
use VV\Verein\MemberProperty;
use Illuminate\Auth\Access\HandlesAuthorization;

class MemberPropertyPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param MemberProperty $memberProperty
     * @return bool
     */
    public function access(User $user, MemberProperty $memberProperty): bool
    {
        return (int)\Session::get('active_club_id') === $memberProperty->club_id;
    }
}
