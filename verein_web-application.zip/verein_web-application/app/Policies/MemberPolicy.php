<?php

namespace VV\Verein\Policies;

use VV\Verein\User;
use VV\Verein\Member;
use Illuminate\Auth\Access\HandlesAuthorization;

class MemberPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param Member $member
     * @return bool
     */
    public function access(User $user, Member $member): bool
    {
        return $member->club_id === (int)\Session::get('active_club_id');
    }
}
