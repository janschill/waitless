<?php

namespace VV\Verein;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use VV\Verein\Fee;
use VV\Verein\Club;
use VV\Verein\Person;
use VV\Verein\Organisation;
use VV\Verein\Membership;
use VV\Verein\MemberPropertyValueRelation;
use Illuminate\Support\Facades\Input;

class Member extends Model
{
    use SoftDeletes;

    const TYPE_PERSON = Person::class;
    const TYPE_ORGANISATION = Organisation::class;

    /**
     * @var array
     */
    protected $dates = [
        'deleted_at',
        'member_since',
    ];

    /**
     * @var array
     */
    protected $fillable = [
        'email',
        'club_id',
        'member_number',
        'street',
        'postal_code',
        'city',
        'telephone',
        'member_since',
        'notes',
        'avatar',
        'confirmed',
        'registered',
        'membership',
        'memberable'
    ];

    public function memberable()
    {
        return $this->morphTo();
    }

    public function memberPropertyValueRelations()
    {
        return $this->hasMany(MemberPropertyValueRelation::class);
    }

    public function fees()
    {
        return $this->hasMany(Fee::class);
    }

    public function membership()
    {
        return $this->hasOne(Membership::class);
    }

    /**
     * @param MemberProperty $memberProperty
     * @return string
     */
    public function getRelatedMemberPropertyValue(MemberProperty $memberProperty): string
    {
        $value = '';

        $value = \VV\Verein\MemberProperty::find($memberProperty->id)
            ->where('type', $memberProperty->type)
            ->with(['memberPropertyValues' => function($query) {
                $query->join('member_property_value_relations as mpvr', 'member_property_values.id', '=', 'mpvr.member_property_value_id')
                    ->where('member_id', $this->id);
            }])
            ->limit(1)
            ->first()
            ->memberPropertyValues->first()->value ?? '';

        return $value;
    }

    /**
     * @param int $memberPropertyId
     * @param int $memberPropertyValueId
     * @return bool
     */
    public function isMemberPropertyRelated(int $memberPropertyId, int $memberPropertyValueId): bool
    {
        $isMemberPropertyRelated = false;

        $memberPropMemberPropertyValueRelation = MemberPropertyValueRelation::where('member_id', $this->id)
            ->where('member_property_value_id', $memberPropertyValueId)
            ->with(['memberPropertyValue' => function($query) use ($memberPropertyId, $memberPropertyValueId) {
                $query->where('member_property_id', $memberPropertyId);
                $query->where('id', $memberPropertyValueId);
            }])
            ->first();

        if($memberPropMemberPropertyValueRelation) {
            $isMemberPropertyRelated = true;
        }

        return $isMemberPropertyRelated;
    }

    /**
     * @param array $memberPropertyValueRelations
     */
    public function updateProperties(array $memberPropertyValueRelations)
    {
        foreach ($memberPropertyValueRelations as $increment => $memberPropertyValueRelation) {
            if(array_key_exists('member_property_value', $memberPropertyValueRelation)) {
                $memberProperty = MemberProperty::findOrFail($memberPropertyValueRelation['member_property_id']);

                // Find records of the given member property and member to update the relation. If none exist, the relation gets created.
                $oldMemberPropertyValueId = MemberProperty::find($memberProperty->id)
                    ->where('type', $memberProperty->type)
                    ->with(['memberPropertyValues' => function($query) {
                        $query->join('member_property_value_relations as mpvr', 'member_property_values.id', '=', 'mpvr.member_property_value_id')
                            ->where('member_id', $this->id);
                    }])
                    ->limit(1)
                    ->first()
                    ->memberPropertyValues->first() ?? null;

                switch ($memberProperty->type) {
                    case MemberProperty::TYPE_SELECT:
                        if($memberPropertyValueRelation['member_property_value'] === null && $oldMemberPropertyValueId) {
                            MemberPropertyValueRelation::where('member_id', $this->id)
                                ->where('member_property_value_id', $oldMemberPropertyValueId->member_property_value_id)
                                ->delete();
                        } elseif ($memberPropertyValueRelation['member_property_value'] !== null) {
                            MemberPropertyValueRelation::updateOrCreate(
                                [
                                    'member_id' => $this->id,
                                    'member_property_value_id' => $oldMemberPropertyValueId->member_property_value_id ?? null
                                ],
                                [
                                    'member_property_value_id' => $memberPropertyValueRelation['member_property_value']
                                ]
                            );
                        }

                        break;
                    case MemberProperty::TYPE_INPUT:
                        if ($memberPropertyValueRelation['member_property_value'] === null && $oldMemberPropertyValueId) {
                            MemberPropertyValueRelation::find($oldMemberPropertyValueId->id)
                                ->delete();

                            MemberPropertyValue::find($oldMemberPropertyValueId->member_property_value_id)
                                ->delete();
                        } elseif ($memberPropertyValueRelation['member_property_value'] !== null) {
                            $memberPropertyValue = MemberPropertyValue::updateOrCreate(
                                [
                                    'member_property_id' => $memberProperty->id,
                                    'value' => $oldMemberPropertyValueId->value ?? null
                                ],
                                [
                                    'value' => $memberPropertyValueRelation['member_property_value']
                                ]
                            );

                            if ($memberPropertyValue->wasRecentlyCreated) {
                                MemberPropertyValueRelation::create([
                                    'member_id' => $this->id,
                                    'member_property_value_id' => $memberPropertyValue->id,
                                    'created_at' => Carbon::now(),
                                    'updated_at' => Carbon::now(),
                                ]);
                            }
                        }

                        break;
                }
            }
        }
    }

    public function setAvatarAttribute($value)
    {
        $filename = null;

        if (Input::hasFile('avatar')) {
            if ($this->avatar) {
                \Storage::disk('public')->delete('/uploads/' . $this->avatar);
            }

            $file = Input::file('avatar');
            $filename = md5($file->getClientOriginalName()) . '.' .$file->extension();
            $file->move(storage_path('app/public/uploads'), $filename);
        }

        $this->attributes['avatar'] = $filename;
    }

    public function setMembershipAttribute($value)
    {
        if($this->id && isset($value['membership_type']) && isset($value['accounting_period'])) {
            Membership::updateOrCreate(
                [
                    'member_id' => $this->id,
                ],
                [
                    'member_id' => $this->id,
                    'additional_fee' => $value['additional_amount'] ?? 0.00,
                    'accounting_period_id' => $value['accounting_period'],
                    'membership_type_id' => $value['membership_type'],
                ]
            );
        }
    }

    public function openFee()
    {
        return $this->fees()
            ->whereColumn('paid_amount', '<', 'amount')
            ->limit(1);
    }
}
