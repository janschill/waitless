<?php

namespace VV\Verein\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use VV\Verein\Member;
use VV\Verein\Club;

class MemberStored extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Member
     */
    public $member = null;

    /**
     * @var Club
     */
    public $club = null;

    public function __construct(Member $member, Club $club)
    {
        $this->member = $member;
        $this->club = $club;
    }

    /**
     * @return $this
     */
    public function build()
    {
        $this->to($this->member->email);
        $this->view('corporate.mails.memberStored');

        return $this;
    }
}
