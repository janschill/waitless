<?php

namespace VV\Verein\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use VV\Verein\Mailing;

/**
 * Generic class that is getting send to all members
 * of a club
 */
class Club extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * @var VV\Verein\Club
     */
    public $club = null;

    /**
     * @var Mailing
     */
    public $mailing = null;

    /**
     * @param Mailing $mailing
     */
    public function __construct(Mailing $mailing)
    {
        $this->mailing = $mailing;
        $this->club = $this->mailing->club;
    }

    /**
     * @return $this
     */
    public function build()
    {
        $this->from[] = [
            'address' => $this->mailing->club->email,
            'name' => $this->mailing->club->name
        ];
        $this->subject = $this->mailing->subject;
        $this->view('backend.mails.club');

        return $this;
    }
}
