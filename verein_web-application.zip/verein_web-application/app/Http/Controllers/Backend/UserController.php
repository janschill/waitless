<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\User;
use VV\Verein\Http\Controllers\AbstractController;
use VV\Verein\Http\Requests\StoreUserRequest;

class UserController extends AbstractController
{
    /**
     * @return View
     */
    public function edit(): View
    {
        return view('backend.templates.user.edit', [
            'user' => \Auth::user()
        ]);
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     */
    public function update(Request $request): RedirectResponse
    {
        \Auth::user()->fill($request->all())->save();

        return \Redirect::back();
    }

    public function create(): View
    {
        return view('backend.templates.user.create');
    }

    /**
     * @param StoreUserRequest $request
     * @return RedirectResponse
     */
    public function store(StoreUserRequest $request): RedirectResponse
    {
        $user = User::create([
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'password' => bcrypt($request->get('password')),
        ]);

        $club = Club::findOrFail(\Session::get('active_club_id'));
        $user->clubs()->attach($club);

        return \Redirect::action('Backend\ClubController@indexUser');
    }

    /**
     * @return RedirectResponse
     */
    public function restore(): RedirectResponse
    {
        // $club->restore();

        return redirect()->action('Corporate\ContentController@index');
    }

    /**
     * @return View
     */
    public function remove(): View
    {
        return view('backend.templates.user.remove', [
            'user' => \Auth::user()
        ]);
    }

    /**
     * @return RedirectResponse
     */
    public function destroy(): RedirectResponse
    {
        $user = \Auth::user();

        if ($user->trashed()) {
            $user->forceDelete();
        } else {
            $user->delete();
        }

        return redirect()->action('Corporate\ContentController@index');
    }
}
