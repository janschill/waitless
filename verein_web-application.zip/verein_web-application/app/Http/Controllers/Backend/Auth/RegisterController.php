<?php

namespace VV\Verein\Http\Controllers\Backend\Auth;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use VV\Verein\Club;
use VV\Verein\User;
use VV\Verein\Http\Controllers\AbstractController;
use VV\Verein\Http\Requests\StoreUserRequest;

class RegisterController extends AbstractController
{
    use RegistersUsers;

    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * @param StoreUserRequest $request
     */
    public function register(StoreUserRequest $request)
    {
        $user = User::create([
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'password' => bcrypt($request->get('password')),
        ]);

        if (!empty($request->get('club')['name'])) {
            // Create a new club and set the relation
            $user->clubs()->create($request->get('club'));
        }

        $this->guard()->login($user);

        return $this->registered($request, $user)
            ?: redirect($this->redirectPath());
    }

    /**
     * @return string
     */
    protected function redirectTo(): string
    {
        return redirect()->action('Backend\DashboardController@index')->getTargetUrl();
    }
}
