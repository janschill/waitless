<?php

namespace VV\Verein\Http\Controllers\Backend\Auth;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\View\View;
use VV\Verein\Http\Controllers\AbstractController;

class LoginController extends AbstractController
{
    use AuthenticatesUsers;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * @return string
     */
    protected function redirectTo(): string
    {
        return redirect()->action('Backend\DashboardController@index')->getTargetUrl();
    }
}
