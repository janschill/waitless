<?php

namespace VV\Verein\Http\Controllers\Backend\Auth;

use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\Http\Controllers\AbstractController;

class ForgotPasswordController extends AbstractController
{
    use SendsPasswordResetEmails;

    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * @return View
     */
    public function showLinkRequestForm(): View
    {
        return view('backend.templates.auth.passwords.email');
    }
}
