<?php

namespace VV\Verein\Http\Controllers\Backend\Auth;

use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\Http\Controllers\AbstractController;

class ResetPasswordController extends AbstractController
{
    use ResetsPasswords;

    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @param string|null $token
     * @return View
     */
    public function showResetForm(Request $request, $token = null): View
    {
        return view('backend.templates.auth.passwords.reset')->with([
            'token' => $token,
            'email' => $request->email
        ]);
    }

    /**
     * @return string
     */
    protected function redirectTo(): string
    {
        return redirect()->action('Corporate\ContentController@index')->getTargetUrl();
    }
}
