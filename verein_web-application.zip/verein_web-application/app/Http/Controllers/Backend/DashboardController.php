<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\Http\Controllers\AbstractController;

class DashboardController extends AbstractController
{
    public function index(): View
    {
        return view('backend.templates.dashboard.index', [
            'notifications' => \Auth::user()->getNotifications()->take(10)
        ]);
    }

    public function statistics(): View
    {
        return view('backend.templates.dashboard.statistics');
    }

    /**
     * @return RedirectResponse;
     */
    public function switchClub(): RedirectResponse
    {
        \Session::put('active_club_id', request('club_id'));

        return \Redirect::back();
    }

    /**
     * @return View
     */
    public function notifications(): View
    {
        return view('backend.templates.dashboard.notifications', [
            'notifications' => \Auth::user()->getNotifications(true)
        ]);
    }
}
