<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;
use VV\Verein\MemberPropertyValue;
use VV\Verein\Http\Requests\StoreMemberPropertyValueRequest;
use VV\Verein\Http\Controllers\AbstractController;

class MemberPropertyValueController extends AbstractController
{
    /**
     * @param StoreMemberPropertyValueRequest $request
     * @return RedirectResponse
     */
    public function store(StoreMemberPropertyValueRequest $request): RedirectResponse
    {
        MemberPropertyValue::create($request->all());

        return \Redirect::back();
    }

    /**
     * @param MemberPropertyValue $memberPropertyValue
     * @return Response
     */
    public function edit(MemberPropertyValue $memberPropertyValue): View
    {
        return view('backend.templates.memberPropertyValue.edit', [
            'memberPropertyValue' => $memberPropertyValue
        ]);
    }

    /**
     * @param Request $request
     * @param MemberPropertyValue $memberPropertyValue
     * @return RedirectResponse
     */
    public function update(Request $request, MemberPropertyValue $memberPropertyValue): RedirectResponse
    {
        $memberPropertyValue->fill($request->all())->save();

        return \Redirect::back();
    }

    /**
     * @param MemberPropertyValue $memberPropertyValue
     * @return View
     */
    public function remove(MemberPropertyValue $memberPropertyValue): View
    {
        return view('backend.templates.memberPropertyValue.remove', [
            'memberPropertyValue' => $memberPropertyValue,
        ]);
    }

    /**
     * @param MemberPropertyValue $memberPropertyValue
     * @return Response
     */
    public function destroy(MemberPropertyValue $memberPropertyValue): RedirectResponse
    {
        $memberPropertyValue->delete();

        return redirect()->action('Backend\MemberController@index');
    }
}
