<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\User;
use VV\Verein\Http\Requests\StoreClubRequest;
use VV\Verein\Http\Requests\StoreNotificationRequest;
use VV\Verein\MemberProperty;
use VV\Verein\Services\ClubService;
use VV\Verein\Http\Controllers\AbstractController;

class ClubController extends AbstractController
{
    /**
     * @var ClubService
     */
    protected $clubService = null;

    /**
     * @param ClubService $clubService
     */
    public function __construct(ClubService $clubService)
    {
        $this->clubService = $clubService;
    }

    /**
     * @return View
     */
    public function create(): View
    {
        return view('backend.templates.club.create');
    }

    /**
     * @param StoreClubRequest $request
     * @return RedirectResponse
     */
    public function store(StoreClubRequest $request): RedirectResponse
    {
        $this->clubService->store($request);

        return redirect()->action('Backend\DashboardController@index');
    }

    /**
     * @return View
     */
    public function edit(): View
    {
        return view('backend.templates.club.edit');
    }

    /**
     * @param Request $request
     * @param Club $club
     * @return RedirectResponse
     */
    public function update(Request $request): RedirectResponse
    {
        $club = Club::findOrFail(\Session::get('active_club_id'));
        $club->fill($request->all())->save();

        return \Redirect::back();
    }

    /**
     * @param Request $request
     * @param Club $club
     * @return RedirectResponse
     */
    public function restore(Request $request, Club $club): RedirectResponse
    {
        $club->restore();

        return redirect('Corporate\ContentController@index');
    }

    /**
     * @return View
     */
    public function remove(): View
    {
        return view('backend.templates.club.remove');
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     */
    public function destroy(Request $request): RedirectResponse
    {
        $club = Club::findOrFail(\Session::get('active_club_id'));

        if ($club->trashed()) {
            $club->users()->detach(\Auth::user());
            $club->forceDelete();
        } else {
            $club->delete();
        }

        \Session::forget('active_club_id');

        return redirect()->action('ContentController@index');
    }

    /**
     * @return View
     */
    public function indexUser(): View
    {
        return view('backend.templates.club.indexUser');
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     */
    public function removeUser(Request $request): RedirectResponse
    {
        if ((int)$request->get('user') === \Auth::user()->id) {
            return \Redirect::back()->withErrors([
                'self_deleting' => 'Du kannst dich nicht selbst aus dem Verein austragen.'
            ]);
        }

        $club = Club::findOrFail(\Session::get('active_club_id'));
        $club->users()->detach($request->get('user'));

        return \Redirect::back();
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     */
    public function storeUser(Request $request): RedirectResponse
    {
        try {
            $user = User::where('email', $request->get('email'))->firstOrFail();
        } catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return redirect()
                ->action('Backend\UserController@create')
                ->withInput()
                ->withErrors([
                    'email' => 'Der Benutzer »' . $request->get('email') . '« konnte nicht gefunden werden'
                ]);
        }

        $club = Club::findOrFail(\Session::get('active_club_id'));

        if ($user && $user->email !== \Auth::user()->email) {
            $club->users()->attach($user);

            \Notification::send($club->users,
                new \VV\Verein\Notifications\Generic(
                    'Neuer Benutzer',
                    $user->first_name . ' wurde als Benutzer hinzugefügt.',
                    $club->id
                )
            );
        } else {
            echo '@TODO: Add message, that user can\'t add himself';
        }

        return \Redirect::back();
    }

    /**
     * @return View
     */
    public function createNotification(): View
    {
        return view('backend.templates.club.createNotification');
    }

    /**
     * @param StoreNotificationRequest $request
     * @return RedirectResponse
     */
    public function storeNotification(StoreNotificationRequest $request): RedirectResponse
    {
        $club = Club::findOrFail(\Session::get('active_club_id'));

        \Notification::send($club->users,
            new \VV\Verein\Notifications\Generic(
                $request->get('headline'),
                $request->get('text'),
                $club->id
            )
        );

        return \Redirect::action('Backend\DashboardController@notifications');
    }

    public function anniversaries(): View
    {
        return view('backend.templates.club.anniversaries');
    }

    public function birthdays(): View
    {
        return view('backend.templates.club.birthdays');
    }
}
