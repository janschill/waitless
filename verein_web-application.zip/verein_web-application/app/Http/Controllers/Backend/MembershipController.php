<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\AccountingPeriod;
use VV\Verein\Member;
use VV\Verein\Http\Controllers\AbstractController;

class MembershipController extends AbstractController
{
    /**
     * @param Request $request
     * @param Member $member
     * @return RedirectResponse
     */
    public function paid(Request $request, Member $member): RedirectResponse
    {
        $membership = $member->membership;
        $fee = $member->openFee->first();
        $amount = 0.00;

        if ((bool)$request->get('part_payment')) {
            $amount = $request->get('amount') ?? 0.00;
        } else {
            $amount = $fee->amount;
        }

        $fee->paid_amount = $amount;
        $fee->save();

        return \Redirect::back();
    }
}
