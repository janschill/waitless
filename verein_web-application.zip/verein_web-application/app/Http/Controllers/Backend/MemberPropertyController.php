<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\MemberProperty;
use VV\Verein\Http\Requests\StoreMemberPropertyRequest;
use VV\Verein\Http\Controllers\AbstractController;

class MemberPropertyController extends AbstractController
{
    /**
     * @return View
     */
    public function create(): View
    {
        return view('backend.templates.memberProperty.create');
    }

    /**
     * @param StoreMemberPropertyRequest $request
     * @return RedirectResponse
     */
    public function store(StoreMemberPropertyRequest $request): RedirectResponse
    {
        MemberProperty::create($request->all());

        return redirect()->action('Backend\MemberPropertyController@create');
    }

    /**
     * @param MemberProperty $memberProperty
     * @return Response
     */
    public function edit(MemberProperty $memberProperty): View
    {
        return view('backend.templates.memberProperty.edit', [
            'memberProperty' => $memberProperty
        ]);
    }

    /**
     * @param Request $request
     * @param MemberProperty $memberProperty
     * @return RedirectResponse
     */
    public function update(Request $request, MemberProperty $memberProperty): RedirectResponse
    {
        $memberProperty->fill($request->all())->save();

        return \Redirect::back();
    }

    /**
     * @param MemberProperty $memberProperty
     * @return View
     */
    public function remove(MemberProperty $memberProperty): View
    {
        return view('backend.templates.memberProperty.remove', [
            'memberProperty' => $memberProperty,
        ]);
    }

    /**
     * @param MemberProperty $memberProperty
     * @return Response
     */
    public function destroy(MemberProperty $memberProperty): RedirectResponse
    {
        $memberProperty->delete();

        return redirect()->action('Backend\MemberController@index');
    }
}
