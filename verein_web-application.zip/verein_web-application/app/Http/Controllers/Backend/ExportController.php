<?php

namespace VV\Verein\Http\Controllers\Backend;

use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\User;
use VV\Verein\Person;
use VV\Verein\Member;
use VV\Verein\Organisation;
use VV\Verein\Http\Controllers\AbstractController;

class ExportController extends AbstractController
{
    /**
     * @var array
     */
    protected $generalTableHeader = [
        'Mitgliedsnummer',
        'E-Mail-Adresse',
        'Straße und Hausnummer',
        'Postleitzahl',
        'Stadt',
        'Telefonnummer',
        'Mitglied seit',
        'Notizen',
        'Bestätigt',
    ];

    /**
     * @var array
     */
    protected $personsTableHeader = [
        'Vorname',
        'Nachname',
        'Spitzname',
        'Geburtstag',
        'Geschlecht',
    ];

    /**
     * @var array
     */
    protected $organisationsTableHeader = [
        'Name',
        'Kontaktperson',
        'Gegründet',
    ];

    /**
     * @return View
     */
    public function index(): View
    {
        return view('backend.templates.export.index');
    }

    public function export()
    {
        $club = Club::findOrFail(\Session::get('active_club_id'));
        $filename = $this->convertToSaveString($club->name) . '-' . Carbon::now()->format('dmY') . '-' . Carbon::now()->format('Hi') . '-vereinfacht';
        $callback = null;
        $headers = [
            'Content-Transfer-Encoding' => 'binary',
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename=' . $filename . '.csv',
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0'
        ];

        // First we need to check of we have persons and organisations. If so we create an zip
        // archive with the csv files to download. Otherwhise we have only persons or only
        // organisations. Under both circumstances we only need to create a single csv file.
        if (Person::whereHas('member')->first() && Organisation::whereHas('member')->first()) {
            $headers['Content-Type'] = 'application/zip';
            $headers['Content-Disposition'] = 'attachment; filename=' . $filename . '.zip';

            $callback = function() use ($filename) {
                $destination = public_path('storage/' . $filename . '.zip');

                $zip = new \ZipArchive();
                $zip->open($destination, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
                $zip->addFromString($filename . '-personen.csv', $this->generatePersonsExport());
                $zip->addFromString($filename . '-organisationen.csv', $this->generateOrganisationsExport());
                $zip->close();

                readfile($destination);

                \Storage::disk('public')->delete($filename . '.zip');
            };
        } elseif(Person::whereHas('member')->first() && !Organisation::whereHas('member')->first()) {
            $callback = function() {
                echo $this->generatePersonsExport();
            };
        } elseif(!Person::whereHas('member')->first() && Organisation::whereHas('member')->first()) {
            $callback = function() {
                echo $this->generateOrganisationsExport();
            };
        }

        return response()->stream($callback, 200, $headers);
    }

    /**
     * @return string
     */
    protected function generatePersonsExport(): string
    {
        $persons = Person::whereHas('member', function($query) {
                $query->where('club_id', \Session::get('active_club_id'));
            })
            ->with('member')
            ->get();
        $tableHeaders = array_merge($this->generalTableHeader, $this->personsTableHeader);
        $content = $this->arrayToCsv($tableHeaders);

        foreach ($persons as $person) {
            $content .= $this->arrayToCsv([
                $person->member->member_number ?? $person->member->id,
                $person->member->email,
                $person->member->street,
                $person->member->postal_code,
                $person->member->city,
                $person->member->telephone,
                Carbon::parse($person->member->member_since)->format('d.m.Y'),
                $person->member->notes,
                $person->member->confirmed ? 'Ja' : 'Nein',

                $person->first_name,
                $person->last_name,
                $person->nickname,
                $person->birthday ? Carbon::parse($person->birthday)->format('d.m.Y') : '',
                $person->getGenderAsString(),
            ]);
        }

        return $content;
    }

    /**
     * @return string
     */
    protected function generateOrganisationsExport(): string
    {
        $organsiations = Organisation::whereHas('member', function($query) {
                $query->where('club_id', \Session::get('active_club_id'));
            })
            ->with('member')
            ->get();
        $tableHeaders = array_merge($this->generalTableHeader, $this->organisationsTableHeader);
        $content = $this->arrayToCsv($tableHeaders);

        foreach ($organsiations as $organsiation) {
            $content .= $this->arrayToCsv([
                $organsiation->member->member_number ?? $organsiation->member->id,
                $organsiation->member->email,
                $organsiation->member->street,
                $organsiation->member->postal_code,
                $organsiation->member->city,
                $organsiation->member->telephone,
                Carbon::parse($organsiation->member->member_since)->format('d.m.Y'),
                $organsiation->member->notes,
                $organsiation->member->confirmed ? 'Ja' : 'Nein',

                $organsiation->name,
                $organsiation->contact_person,
                $organsiation->founded ? Carbon::parse($organsiation->founded)->format('d.m.Y') : '',
            ]);
        }

        return $content;
    }

    /**
     * @param array $array
     * @return string
     */
    protected function arrayToCsv(array $array): string
    {
        return '"' . implode('";"', $array) . '"' . PHP_EOL;
    }

    /**
     * @param string $string
     * @return string
     */
    protected function convertToSaveString(string $string): string
    {
        $saveString = '';

        $saveString = str_replace(
            [' ', '-', '.', 'ä', 'ü', 'ö', 'ß'],
            ['_', '_', '', 'ae', 'ue', 'oe', 'ss'],
            strtolower($string)
        );

        return $saveString;
    }
}
