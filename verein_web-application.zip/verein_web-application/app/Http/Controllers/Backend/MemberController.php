<?php

namespace VV\Verein\Http\Controllers\Backend;

use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\AccountingPeriod;
use VV\Verein\Club;
use VV\Verein\Person;
use VV\Verein\Organisation;
use VV\Verein\Http\Requests\StoreMemberRequest;
use VV\Verein\Notifications\MemberStored;
use VV\Verein\Notifications\MemberDestroyed;
use VV\Verein\Member;
use VV\Verein\MemberPropertyValueRelation;
use VV\Verein\Http\Controllers\AbstractController;

class MemberController extends AbstractController
{
    /**
     * @return View
     */
    public function index(): View
    {
        return view('backend.templates.member.index');
    }

    /**
     * @return View
     */
    public function create(): View
    {
        return view('backend.templates.member.create');
    }

    /**
     * @param StoreMemberRequest $request
     * @return RedirectResponse
     */
    public function store(StoreMemberRequest $request): RedirectResponse
    {
        $morph = $request->get('memberable_type');
        $morph = $morph::create($request->all());
        $member = $morph->member()->create($request->all());
        $member->updateProperties($request->get('member_property_value_relations') ?? []);
        $member->setMembershipAttribute($request->get('membership'));

        $club = Club::findOrFail($request->session()->get('active_club_id'));
        if ($club->users) {
            \Notification::send($club->users, new MemberStored($member));
        }

        return redirect()->action('Backend\MemberController@index');
    }

    /**
     * @param Member $member
     * @return View
     */
    public function edit(Member $member): View
    {
        return view('backend.templates.member.edit', [
            'member' => $member
        ]);
    }

    /**
     * @param Request $request
     * @param Member $member
     * @return RedirectResponse
     */
    public function update(Request $request, Member $member): RedirectResponse
    {
        $member->updateProperties($request->member_property_value_relations ?? []);
        $member->fill($request->all())->save();
        $member->memberable->fill($request->all())->save();

        return \Redirect::back();
    }

    /**
     * @param Member $member
     * @return View
     */
    public function remove(Member $member): View
    {
        return view('backend.templates.member.remove', [
            'member' => $member,
        ]);
    }

    /**
     * @param Member $member
     * @return RedirectResponse
     */
    public function destroy(Member $member): RedirectResponse
    {
        $member->delete();

        $club = Club::findOrFail(\Session::get('active_club_id'));
        if ($club->users) {
            \Notification::send($club->users, new MemberDestroyed($member));
        }

        return redirect()->action('Backend\MemberController@index');
    }

    /**
     * @param Member $member
     * @return RedirectResponse
     */
    public function confirm(Member $member): RedirectResponse
    {
        $member->confirmed = true;
        $member->save();

        return \Redirect::back();
    }
}
