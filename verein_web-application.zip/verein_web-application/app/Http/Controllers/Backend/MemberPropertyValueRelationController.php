<?php

namespace VV\Verein\Http\Controllers\Backend;

use VV\Verein\MemberPropertyValueRelation;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use VV\Verein\Http\Controllers\AbstractController;

class MemberPropertyValueRelationController extends AbstractController
{
    /**
     * @return Response
     */
    public function index()
    {
    }

    /**
     * @return Response
     */
    public function create()
    {
    }

    /**
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * @param MemberPropertyValueRelation $memberPropertyValueRelation
     * @return Response
     */
    public function show(MemberPropertyValueRelation $memberPropertyValueRelation)
    {
    }

    /**
     * @param MemberPropertyValueRelation $memberPropertyValueRelation
     * @return Response
     */
    public function edit(MemberPropertyValueRelation $memberPropertyValueRelation)
    {
    }

    /**
     * @param Request $request
     * @param MemberPropertyValueRelation $memberPropertyValueRelation
     * @return Response
     */
    public function update(Request $request, MemberPropertyValueRelation $memberPropertyValueRelation)
    {
    }

    /**
     * @param MemberPropertyValueRelation $memberPropertyValueRelation
     * @return Response
     */
    public function destroy(MemberPropertyValueRelation $memberPropertyValueRelation)
    {
    }
}
