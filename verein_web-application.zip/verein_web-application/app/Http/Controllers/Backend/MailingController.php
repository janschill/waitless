<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\Mailing;
use VV\Verein\Mail\Club;
use VV\Verein\Http\Requests\StoreMailingRequest;
use VV\Verein\Http\Controllers\AbstractController;

class MailingController extends AbstractController
{
    /**
     * @return View
     */
    public function index(): View
    {
        $mailings = Mailing::where('club_id', \Session::get('active_club_id'))
            ->orderBy('created_at', 'DESC')
            ->get();

        return view('backend.templates.mailing.index', [
            'mailings' => $mailings
        ]);
    }

    /**
     * @return View
     */
    public function create(): View
    {
        return view('backend.templates.mailing.create');
    }

    /**
     * @param StoreMailingRequest $request
     * @return View
     */
    public function store(StoreMailingRequest $request): RedirectResponse
    {
        $mailing = Mailing::create($request->all() + [
            'club_id' => \Session::get('active_club_id')
        ]);

        $mailType = $request->get('mail_type');
        $club = \VV\Verein\Club::find(\Session::get('active_club_id'));

        if ($club) {
            foreach ($club->members as $member) {
                \Mail::to($member->email)
                    ->queue(new $mailType($mailing));
            }
        }

        return redirect()->action('Backend\MailingController@index');
    }

    /**
     * @param Mailing $mailing
     * @return View
     */
    public function show(Mailing $mailing): View
    {
        return view('backend.templates.mailing.show', [
            'mailing' => $mailing
        ]);
    }

    /**
     * @param Mailing $mailing
     */
    public function preview(Mailing $mailing)
    {
        return (new Club($mailing))->render();
    }
}
