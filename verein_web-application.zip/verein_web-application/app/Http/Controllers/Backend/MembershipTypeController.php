<?php

namespace VV\Verein\Http\Controllers\Backend;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use VV\Verein\AccountingPeriod;
use VV\Verein\MembershipType;
use VV\Verein\Http\Controllers\AbstractController;
use VV\Verein\Http\Requests\StoreMembershipTypeRequest;

class MembershipTypeController extends AbstractController
{
    /**
     * @return View
     */
    public function create(): View
    {
        return view('backend.templates.membershipType.create', [
            'accountingPeriods' => AccountingPeriod::all()
        ]);
    }

    /**
     * @param StoreMembershipTypeRequest $request
     * @return RedirectResponse
     */
    public function store(StoreMembershipTypeRequest $request): RedirectResponse
    {
        $membershipType = MembershipType::create($request->all() + ['club_id' => \Session::get('active_club_id')]);
        $membershipType->accountingPeriods()->attach($request->get('accounting_periods'));

        return \Redirect::back();
    }

    /**
     * @param MembershipType $membershipType
     * @return View
     */
    public function edit(MembershipType $membershipType): View
    {
        return view('backend.templates.membershipType.edit', [
            'membershipType' => $membershipType,
            'accountingPeriods' => AccountingPeriod::all()
        ]);
    }

    /**
     * @param StoreMembershipTypeRequest $request
     * @param MembershipType $membershipType
     * @return RedirectResponse
     */
    public function update(StoreMembershipTypeRequest $request, MembershipType $membershipType): RedirectResponse
    {
        $membershipType->fill($request->all())->save();

        return \Redirect::back();
    }
}
