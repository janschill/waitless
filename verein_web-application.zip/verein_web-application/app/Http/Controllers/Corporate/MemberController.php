<?php

namespace VV\Verein\Http\Controllers\Corporate;

use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Input;
use Illuminate\View\View;
use VV\Verein\Club;
use VV\Verein\Member;
use VV\Verein\Http\Requests\StoreMemberRequest;
use VV\Verein\Http\Controllers\AbstractController;
use VV\Verein\Notifications\MemberStored as MemberStoredNotification;
use VV\Verein\Mail\MemberStored as MemberStoredMail;

class MemberController extends AbstractController
{
    /**
     * @param Club $club
     * @return View
     */
    public function create(Club $club): View
    {
        return view('corporate.templates.member.create', [
            'club' => $club
        ]);
    }

    /**
     * @param Club $club
     * @param StoreMemberRequest $request
     * @return RedirectResponse
     */
    public function store(Club $club, StoreMemberRequest $request): RedirectResponse
    {
        $member = Member::create($request->all());
        $member->updateProperties($request->get('member_property_value_relations') ?? []);

        \Mail::send(new MemberStoredMail($member, $club));

        return redirect()
            ->action('Corporate\MemberController@confirmation', ['club' => $club]);
    }

    /**
     * @param Club $club
     * @return View
     */
    public function confirmation(Club $club): View
    {
        return view('corporate.templates.member.confirmation', [
            'club' => $club
        ]);
    }

    /**
     * @param Club $club
     * @return View
     */
    public function register(Club $club): View
    {
        $member = Member::where('id', request('member'))
            ->where('club_id', $club->id)
            ->firstOrFail();

        $member->registered = true;
        $member->save();

        \Notification::send($club->users, new MemberStoredNotification($member));

        return view('corporate.templates.member.register');
    }
}
