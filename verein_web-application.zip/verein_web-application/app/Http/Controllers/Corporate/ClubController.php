<?php

namespace VV\Verein\Http\Controllers\Corporate;

use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use VV\Verein\Http\Controllers\AbstractController;
use VV\Verein\Http\Requests\StoreClubRequest;
use VV\Verein\Club;
use VV\Verein\Services\ClubService;

class ClubController extends AbstractController
{
    /**
     * @var ClubService
     */
    protected $clubService = null;

    /**
     * @param ClubService $clubService
     */
    public function __construct(ClubService $clubService)
    {
        $this->clubService = $clubService;
    }

    /**
     * @return View
     */
    public function create(): View
    {
        return view('corporate.templates.club.create');
    }

    /**
     * @param StoreClubRequest $request
     * @return RedirectResponse
     */
    public function store(StoreClubRequest $request): RedirectResponse
    {
        $this->clubService->store($request);

        return redirect()->action('Backend\DashboardController@index');
    }
}
