<?php

namespace VV\Verein\Http\Controllers\Corporate;

use Illuminate\View\View;
use VV\Verein\Http\Controllers\AbstractController;

class ContentController extends AbstractController
{
    /**
     * @return View
     */
    public function index(): View
    {
        return view('corporate.templates.index');
    }

    /**
     * @return View
     */
    public function imprint(): View
    {
        return view('corporate.templates.imprint');
    }

    /**
     * @return View
     */
    public function about(): View
    {
        return view('corporate.templates.about');
    }
}
