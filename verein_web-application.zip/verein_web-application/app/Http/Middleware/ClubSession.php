<?php

namespace VV\Verein\Http\Middleware;

use \Auth;
use Closure;
use \Session;
use VV\Verein\Club;
use \View;

class ClubSession
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request  $request
     * @param \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $club = null;

        if (Session::get('active_club_id')) {
            $club = Club::findOrFail(Session::get('active_club_id'));
        } elseif (Auth::user()->clubs->count() > 0) {
            $club = Auth::user()->clubs->first();
            Session::put('active_club_id', $club->id);
        } else {
            return \Redirect::action('Corporate\ClubController@create');
        }

        View::share('club', $club);

        return $next($request);
    }
}
