<?php

namespace VV\Verein\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use VV\Verein\MemberProperty;

class StoreMemberPropertyValueRequest extends FormRequest
{
    /**
     * @return bool
     */
    public function authorize(): bool
    {
        $memberProperty = MemberProperty::findOrFail($this->get('member_property_id'));
        return \Auth::user()->can('access', $memberProperty);
    }

    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'value' => ['required']
        ];
    }
}
