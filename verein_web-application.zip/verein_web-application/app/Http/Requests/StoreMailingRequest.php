<?php

namespace VV\Verein\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreMailingRequest extends FormRequest
{
    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'subject' => ['required'],
            'text' => ['required'],
            'mail_type' => ['required'],
        ];
    }
}
