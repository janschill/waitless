<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\AccountingPeriod;
use VV\Verein\Membership;

class MembershipType extends Model
{
    /**
     * @var array
     */
    protected $fillable = [
        'title',
        'monthly_fee',
        'club_id',
        'accounting_periods'
    ];

    public function memberships()
    {
        return $this->belongsToMany(Membership::class);
    }

    public function accountingPeriods()
    {
        return $this->belongsToMany(AccountingPeriod::class);
    }

    public function setAccountingPeriodsAttribute($value)
    {
        if($this->id) {
            $this->accountingPeriods()->sync($value);
        }
    }
}
