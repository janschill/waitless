<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\Member;
use VV\Verein\MemberPropertyValue;

class MemberPropertyValueRelation extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['member_id', 'member_property_value_id'];

    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function memberPropertyValue()
    {
        return $this->belongsTo(MemberPropertyValue::class);
    }
}
