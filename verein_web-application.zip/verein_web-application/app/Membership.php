<?php

namespace VV\Verein;

use Illuminate\Database\Eloquent\Model;
use VV\Verein\AccountingPeriod;
use VV\Verein\Fee;
use VV\Verein\Member;
use VV\Verein\MembershipType;

class Membership extends Model
{
    /**
     * @var array
     */
    protected $fillable = [
        'member_id',
        'additional_fee',
        'accounting_period_id',
        'membership_type_id'
    ];

    public function membershipType()
    {
        return $this->belongsTo(MembershipType::class);
    }

    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function accountingPeriod()
    {
        return $this->belongsTo(AccountingPeriod::class);
    }

    public function fees()
    {
        return $this->hasMany(Fee::class);
    }
}
