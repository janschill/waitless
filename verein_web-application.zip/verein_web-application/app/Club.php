<?php

namespace VV\Verein;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Input;
use VV\Verein\Mailing;
use VV\Verein\Member;
use VV\Verein\MembershipType;
use VV\Verein\MemberProperty;
use VV\Verein\Organisation;
use VV\Verein\Person;
use VV\Verein\User;

class Club extends Model
{
    use SoftDeletes;

    /**
     * @var array
     */
    protected $dates = [
        'deleted_at',
        'founding_date'
    ];

    /**
     * @var array
     */
    protected $fillable = [
        'name',
        'logo',
        'website',
        'email',
        'street',
        'postal_code',
        'city',
        'founding_date',
        'referral_id',
    ];

    public function users()
    {
        return $this->belongsToMany(User::class);
    }

    public function members()
    {
        return $this->hasMany(Member::class);
    }

    public function memberProperties()
    {
        return $this->hasMany(MemberProperty::class);
    }

    public function membershipTypes()
    {
        return $this->hasMany(MembershipType::class);
    }

    public function mailings()
    {
        return $this->hasMany(Mailing::class);
    }

    /**
     * @return int
     */
    public function countLatestNewMembers(): int
    {
        return Member::where('club_id', $this->id)
            ->where('created_at', '>=', Carbon::now()->modify('-7 days'))
            ->count();
    }

    /**
     * @return int
     */
    public function countLatestRemovedMembers(): int
    {
        return Member::withTrashed()
            ->where('club_id', $this->id)
            ->where('deleted_at', '>=', Carbon::now()->modify('-7 days'))
            ->count();
    }

    /**
     * @return float
     */
    public function ratioBetweenNewAndRemovedMembers(): float
    {
        $ratio = 0.0;

        if ($this->countLatestRemovedMembers() > 0 || $this->countLatestNewMembers() > 0) {
            $ratio = 100 / ($this->countLatestNewMembers() + $this->countLatestRemovedMembers()) * $this->countLatestNewMembers();
        }

        return $ratio;
    }

    /**
     * @return float
     */
    public function ratioBetweenRemovedAndNewMembers(): float
    {
        $ratio = 0.0;

        if ($this->countLatestNewMembers() > 0 || $this->countLatestRemovedMembers() > 0) {
            $ratio = 100 / ($this->countLatestRemovedMembers() + $this->countLatestNewMembers()) * $this->countLatestRemovedMembers();
        }

        return $ratio;
    }

    /**
     * @param int $limit
     */
    public function getBirthdayPersons(int $limit = 3)
    {
        $persons = Member::where('club_id', $this->id)
            ->join('persons', function($query) {
                $query->on('persons.id', '=', 'members.memberable_id');
                $query->where('members.memberable_type', '=', Person::class);
                $query->whereNotNull('persons.birthday');
            })
            ->orderByRaw('MONTH(birthday) ASC, DAY(birthday) ASC')
            ->select('members.id as member_id', 'persons.*')
            ->get();

        return $persons;
    }

    /**
     * @param int $limit
     */
    public function getBirthdayOrganisations(int $limit = 3)
    {
        $organisations = Member::where('club_id', $this->id)
            ->join('organisations', function($query) {
                $query->on('organisations.id', '=', 'members.memberable_id');
                $query->where('members.memberable_type', '=', Organisation::class);
                $query->whereNotNull('organisations.founded');
            })
            ->orderByRaw('MONTH(founded) ASC, DAY(founded) ASC')
            ->select('members.id as member_id', 'organisations.*')
            ->get();

        return $organisations;
    }

    /**
     * @param int $limit
     */
    public function getAnniversaryMembers(int $limit = 3)
    {
        $members = Member::whereNotNull('member_since')
            ->where('club_id', $this->id)
            ->whereYear('member_since', '<', date('Y'))
            ->orderByRaw('MONTH(member_since) ASC, DAY(member_since) ASC')
            ->limit($limit)
            ->get();

        return $members;
    }

    public function setLogoAttribute($value)
    {
        $filename = null;

        if (Input::hasFile('logo')) {
            if ($this->logo) {
                \Storage::disk('public')->delete('/uploads/' . $this->logo);
            }

            $file = Input::file('logo');
            $filename = md5($file->getClientOriginalName()) . '.' .$file->extension();
            $file->move(storage_path('app/public/uploads'), $filename);
        }

        $this->attributes['logo'] = $filename;
    }

    public function getAccountPeroidsForSelect()
    {
        $accountingPeriods = [];

        foreach ($this->membershipTypes as $membershipType) {
            foreach ($membershipType->accountingPeriods as $accountingPeriod) {
                $accountingPeriods[$membershipType->id][] = [
                    'title' => $accountingPeriod->title,
                    'id' => $accountingPeriod->id
                ];
            }
        }

        return json_encode($accountingPeriods);
    }

    public function getMonthlyEarnings(): float
    {
        $earnings = 0.00;

        $members = Member::where('club_id', $this->id)
            ->with(['membership' => function($query) {
                $query->with('membershipType');
            }])
            ->get();

        foreach ($members as $member) {
            if ($member->membership) {
                $earnings += $member->membership->additional_fee ?? 0.0;

                if ($member->membership->membershipType) {
                    $earnings += $member->membership->membershipType->monthly_fee ?? 0.0;
                }
            }
        }

        return $earnings;
    }
}
