(function () {

  var initForm = function($form) {
    var $formSelectChangeViews = $form.querySelectorAll('.form__select.form__select--change-views'),
      $formView = $form.querySelectorAll('.form__view');

    for (var i = $formSelectChangeViews.length - 1; i >= 0; i--) {
      $formSelectChangeViews[i].addEventListener('change', function() {
        for (var k = $formView.length - 1; k >= 0; k--) {

          if ($formView[k].dataset.viewGroup === this.options[this.selectedIndex].dataset.viewGroup) {
            $formView[k].classList.remove('form__view--active');

            var $formViewInputElements = $formView[k].querySelectorAll('input, textarea, select')

            for (var j = $formViewInputElements.length - 1; j >= 0; j--) {
              $formViewInputElements[j].disabled = true;
            }

            if (this.options[this.selectedIndex].dataset.viewKey === $formView[k].dataset.viewKey) {
              $formView[k].classList.add('form__view--active');

              for (var j = $formViewInputElements.length - 1; j >= 0; j--) {
                $formViewInputElements[j].disabled = false;
              }
            }
          }
        }
      });

      var changeEvent = new Event('change');
      $formSelectChangeViews[i].dispatchEvent(changeEvent);
    }
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $form = document.querySelectorAll('.form');

    for (var i = $form.length - 1; i >= 0; i--) {
      initForm($form[i]);
    }
  });

}());
