(function () {

  var initOverview = function($overview) {
    if ($overview.classList.contains('overview--searchable')) {
      var $overviewTable = $overview.querySelector('.overview__table');

      new DataTable($overviewTable, {
        columns: [
          {
            select: 0,
            sort: 'desc'
          }
        ],
        perPage: 10,
        perPageSelect: [10],
        sortable: true,
        searchable: true,
        nextPrev: true,
        firstLast: false,
        prevText: '&lsaquo;',
        nextText: '&rsaquo;',
        firstText: '&laquo;',
        lastText: '&raquo;',
        ellipsisText: '&hellip;',
        ascText: '▴',
        descText: '▾',
        truncatePager: true,
        pagerDelta: 2,
        fixedColumns: true,
        fixedHeight: false,
        header: true,
        footer: false,
        labels: {
          placeholder: $overview.dataset.placeholder,
          perPage: '{select} entries per page',
          noRows: $overview.dataset.noRows,
          info: $overview.dataset.info
        },
        layout: {
          top: '{search}',
          bottom: '{pager}{info}'
        }
      });
    }
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $overview = document.querySelectorAll('.overview');

    for (var i = $overview.length - 1; i >= 0; i--) {
      initOverview($overview[i]);
    }
  });

}());
