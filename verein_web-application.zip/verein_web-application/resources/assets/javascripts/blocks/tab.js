(function () {

  var initTab = function($tab) {
    var $tabTrigger = $tab.querySelectorAll('.tab__trigger'),
      $tabView = $tab.querySelectorAll('.tab__view');

    for (var i = $tabTrigger.length - 1; i >= 0; i--) {
      $tabTrigger[i].addEventListener('click', function() {

        for (var j = $tabTrigger.length - 1; j >= 0; j--) {
          $tabTrigger[j].classList.remove('tab__trigger--active');
        }

        this.classList.add('tab__trigger--active');

        for (var k = $tabView.length - 1; k >= 0; k--) {
          $tabView[k].classList.remove('tab__view--active');

          if (this.dataset.key === $tabView[k].dataset.key) {
            $tabView[k].classList.add('tab__view--active');
          }
        }
      });
    }
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $tab = document.querySelectorAll('.tab');

    for (var i = $tab.length - 1; i >= 0; i--) {
      initTab($tab[i]);
    }
  });

}());
