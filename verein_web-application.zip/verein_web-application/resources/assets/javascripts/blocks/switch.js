(function () {

  var initSwitch = function($switch) {
    var $switchSelect = $switch.querySelector('.switch__select');

    $switchSelect.addEventListener('change', function() {
      $switch.submit();
    });
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $switch = document.querySelectorAll('.switch');

    for (var i = $switch.length - 1; i >= 0; i--) {
      initSwitch($switch[i]);
    }
  });

}());
