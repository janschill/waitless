(function () {

  var initNavigationMain = function($navigationMain) {
    var $navigationMainLinks = $navigationMain.querySelectorAll('.navigation-main__link');

    for (var i = $navigationMainLinks.length - 1; i >= 0; i--) {
      $navigationMainLinks[i].addEventListener('click', function(event) {
        if (!window.matchMedia('(min-width: 850px)').matches) {
          event.preventDefault();
        }
      });
    }
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $navigationMain = document.querySelectorAll('.navigation-main');

    for (var i = $navigationMain.length - 1; i >= 0; i--) {
      initNavigationMain($navigationMain[i]);
    }
  });

}());
