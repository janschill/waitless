(function () {

  var initTeaserUser = function($teaserUser) {
    var $teaserUserLinks = $teaserUser.querySelectorAll('.teaser-user__link');

    for (var i = $teaserUserLinks.length - 1; i >= 0; i--) {
      $teaserUserLinks[i].addEventListener('click', function(event) {
        if (!window.matchMedia('(min-width: 850px)').matches) {
          event.preventDefault();
        }
      });
    }
  };

  document.addEventListener('DOMContentLoaded', function() {
    var $teaserUser = document.querySelectorAll('.teaser-user');

    for (var i = $teaserUser.length - 1; i >= 0; i--) {
      initTeaserUser($teaserUser[i]);
    }
  });

}());
