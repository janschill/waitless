        <!--[if lt IE 11]>
            <aside class="browse-happy">Der benutzte Webbrowser ist veraltet. Einige Bereiche dieser Webseite werden deshalb nicht funktionieren. Jetzt einen neuen sicheren Webbrowser <a class="browse-happy__link" target="_blank" href="https://browsehappy.com/">herunterladen</a>.</aside>
        <![endif]-->
