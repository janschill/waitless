<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 235 377.5" xml:space="preserve">
    <path class="icon__path" class="st0" d="M63.4,218.2L46.1,360l71.4-46.7l71.4,46.7l-17.3-142 M117.5,17.5c55.2,0,100,48.8,100,109 s-44.8,109-100,109s-100-48.8-100-109S62.3,17.5,117.5,17.5z" />
</svg>
