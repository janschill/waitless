<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 335" xml:space="preserve">
    <path class="icon__path" d="M77.5,197.5h180v120h-180V197.5z M77.5,257.5h-30c-16.6,0-30-13.4-30-30v-75 c0-16.6,13.4-30,30-30h240c16.6,0,30,13.4,30,30v75c0,16.6-13.4,30-30,30h-30 M77.5,122.5v-105h180v105" />
</svg>
