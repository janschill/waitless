<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 285 235" xml:space="preserve">
    <path class="icon__path" d="M42.5,17.5h200c13.75,0,25,11.25,25,25v150c0,13.75-11.25,25-25,25h-200c-13.75,0-25-11.25-25-25v-150 C17.5,28.75,28.75,17.5,42.5,17.5z" />
    <polyline class="icon__path" points="267.5,42.5 142.5,130 17.5,42.5 " />
</svg>
