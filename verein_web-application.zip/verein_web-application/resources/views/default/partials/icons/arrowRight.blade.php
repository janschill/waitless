<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 249" xml:space="preserve">
    <path class="icon__path" d="M205,17.5l112.5,107L205,231.5 M17.5,124.5h300" />
</svg>
