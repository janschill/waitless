<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 360 398.4" xml:space="preserve">
    <path class="icon__path" d="M234.2,199.2H17.5 M161.9,271.9l72.2-72.7l-72.2-72.7 M216.1,380.9h90.3c19.9,0,36.1-16.3,36.1-36.3V53.8 c0-20.1-16.2-36.3-36.1-36.3h-90.3" />
</svg>
