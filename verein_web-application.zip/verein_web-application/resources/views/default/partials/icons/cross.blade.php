<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 285 285" xml:space="preserve">
    <line class="icon__path" x1="17.5" y1="267.5" x2="267.5" y2="17.5" />
    <line class="icon__path" x1="17.5" y1="17.5" x2="267.5" y2="267.5" />
</svg>
