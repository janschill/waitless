<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 305" xml:space="preserve">
    <polyline class="icon__path" points="317.5,152.5 257.5,152.5 212.5,287.5 122.5,17.5 77.5,152.5 17.5,152.5 "/>
</svg>
