<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 185 342.5" xml:space="preserve">
    <polyline class="icon__path" points="17.5,325 167.5,171.2 17.5,17.5 " />
</svg>
