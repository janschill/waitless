<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 310 310" xml:space="preserve">
    <path class="icon__path" d="M292.5,292.5l-79.4-79.4 M132.1,17.5c63.3,0,114.6,51.3,114.6,114.6c0,63.3-51.3,114.6-114.6,114.6 S17.5,195.4,17.5,132.1C17.5,68.8,68.8,17.5,132.1,17.5z" />
</svg>
