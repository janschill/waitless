<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 385 385" xml:space="preserve">
    <path class="icon__path" d="M122.5,192.5h140 M192.5,122.5v140 M192.5,17.5c96.6,0,175,78.4,175,175s-78.4,175-175,175 s-175-78.4-175-175S95.9,17.5,192.5,17.5z" />
</svg>
