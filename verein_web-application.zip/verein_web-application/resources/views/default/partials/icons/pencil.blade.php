<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 335" xml:space="preserve">
    <polygon class="icon__path" points="234.2,17.5 317.5,100.8 100.8,317.5 17.5,317.5 17.5,234.2 " />
</svg>
