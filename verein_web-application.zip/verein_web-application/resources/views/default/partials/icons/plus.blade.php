<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 285 285" xml:space="preserve">
    <path class="icon__path" d="M17.5,142.5h250 M142.5,17.5v250" />
</svg>
