<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 385 317.2" xml:space="preserve">
    <path class="icon__path" d="M367.5,142.9H272 M136.8,17.5c35.1,0,63.6,28.1,63.6,62.7s-28.5,62.7-63.6,62.7 s-63.6-28.1-63.6-62.7S101.7,17.5,136.8,17.5z M256.1,299.7v-31.3c0-34.6-28.5-62.7-63.6-62.7H81.1c-35.1,0-63.6,28.1-63.6,62.7 v31.3" />
</svg>
