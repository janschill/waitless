<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 310 310" xml:space="preserve">
    <path class="icon__path" d="M17.5,185.6h106.9v106.9H17.5V185.6z M185.6,185.6h106.9v106.9H185.6V185.6z M185.6,17.5 h106.9v106.9H185.6V17.5z M17.5,17.5h106.9v106.9H17.5V17.5z" />
</svg>
