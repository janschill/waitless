<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 334.9" xml:space="preserve">
    <path class="icon__path" d="M193.5,302.5c-8.3,14.3-26.7,19.2-41,10.9c-4.5-2.6-8.3-6.4-10.9-10.9 M317.5,242.5h-300 c24.9,0,45-20.1,45-45v-75c0-58,47-105,105-105s105,47,105,105v75C272.5,222.3,292.6,242.5,317.5,242.5z" />
</svg>
