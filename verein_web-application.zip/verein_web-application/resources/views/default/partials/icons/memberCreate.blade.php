<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 385 323.3" xml:space="preserve">
    <path class="icon__path" d="M367.5,145.6h-95.4 M319.8,97.6v96.1 M136.8,17.5c35.2,0,63.6,28.7,63.6,64.1 c0,35.4-28.5,64.1-63.6,64.1S73.2,117,73.2,81.6C73.2,46.2,101.7,17.5,136.8,17.5z M256.1,305.8v-32c0-35.4-28.5-64.1-63.6-64.1 H81.1c-35.2,0-63.6,28.7-63.6,64.1v32" />
</svg>
