<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 360 398.8" xml:space="preserve">
    <path class="icon__path" d="M125.9,199.4h216.6 M198.1,126.6l-72.2,72.8l72.2,72.8 M143.9,381.3H53.6 c-19.9,0-36.1-16.3-36.1-36.4v-291c0-20.1,16.2-36.4,36.1-36.4h90.3" />
</svg>
