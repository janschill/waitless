<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 285 355.3" xml:space="preserve">
    <path class="icon__path" d="M111.2,129.6H95.6H80 M205,257.7H80 M205,193.7H80 M173.8,17.5v96.1h93.8 M173.8,17.5h-125 c-17.3,0-31.2,14.3-31.2,32v256.3c0,17.7,14,32,31.2,32h187.5c17.3,0,31.2-14.3,31.2-32V113.6L173.8,17.5z" />
</svg>
