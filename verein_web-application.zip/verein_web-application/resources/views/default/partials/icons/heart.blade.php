<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 300 257.5" xml:space="preserve">
    <path class="icon__path" d="M276.9,22.8c-30.8-30.4-80.8-30.4-111.6,0l0,0l-15.2,15l-15.2-15C104-7.6,54-7.6,23.1,22.8s-30.8,79.5,0,109.9 l15.2,15L150,257.5l111.7-109.9l15.2-15C307.7,102.3,307.7,53.1,276.9,22.8L276.9,22.8" />
</svg>
