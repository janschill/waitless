<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 285 285" xml:space="preserve">
    <path class="icon__path" d="M239.722,267.5H45.278c-15.341,0-27.778-12.437-27.778-27.778V45.278C17.5,29.937,29.937,17.5,45.278,17.5 h152.778L267.5,86.944v152.778C267.5,255.063,255.063,267.5,239.722,267.5z "/>
    <polyline class="icon__path" points="211.944,267.5 211.944,156.389 73.056,156.389 73.056,267.5 "/>
    <polyline class="icon__path" points="73.056,17.5 73.056,86.944 184.167,86.944 "/>
</svg>
