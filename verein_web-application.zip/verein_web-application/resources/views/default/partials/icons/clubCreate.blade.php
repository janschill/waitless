<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 350 379.6" xml:space="preserve">
    <path class="icon__path" d="M0,0L0,0v251.4c0,49.3,175,128.2,175,128.2s175-78.9,175-128.2V0H0z M58.2,58.2h233.6v183.4c-15,16.8-64.8,48-116.8,73.7 c-52-25.6-101.8-56.9-116.8-73.7V58.2z" />
    <path class="icon__path" d="M110.3,174.2h129.4 M175,109.5v129.4" />
</svg>
