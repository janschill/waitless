<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 310 203.1" xml:space="preserve">
    <polyline class="icon__path" points="292.5,17.5 103.4,185.6 17.5,109.2 " />
</svg>
