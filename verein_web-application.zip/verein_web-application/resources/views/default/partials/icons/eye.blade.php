<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 253.182" xml:space="preserve">
    <path class="icon__path" d="M17.5,126.591c0,0,54.545-109.091,150-109.091s150,109.091,150,109.091s-54.545,109.091-150,109.091 S17.5,126.591,17.5,126.591z" />
    <circle class="icon__path" cx="167.5" cy="126.591" r="40.909" />
</svg>
