<svg class="icon" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 335 305.5" xml:space="preserve">
    <path class="icon__path" d="M17.5,167.8h60V288h-60V167.8z M257.5,92.6h60V288h-60V92.6z M137.5,17.5h60V288h-60V17.5z" />
</svg>
