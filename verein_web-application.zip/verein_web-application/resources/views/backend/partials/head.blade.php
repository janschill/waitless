<meta charset="utf-8">

<meta name="author" content="visuellverstehen">
<meta name="description" content="{{ config('app.name') }}">
<meta name="robots" content="noindex, nofollow">
<meta name="application-name" content="{{ config('app.name') }}">
<meta name="theme-color" content="#ffffff">
<meta name="msapplication-config" content="{{ URL::asset('browserconfig.xml') }}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta property="og:image" content="{{ URL::asset('images/meta/vereinfacht-1200-630.png') }}">

<title>@yield('pageTitle') – {{ config('app.name') }}</title>

<!-- visuellverstehen – Design and Development – @vv_agentur -->
<!--[if lt IE 9]><script src="{{ URL::asset('javascripts/html5shiv.js') }}"></script><![endif]-->

<link rel="shortcut icon" type="image/x-icon" href="{{ URL::asset('images/meta/vereinfacht-backend-32-32.ico') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ URL::asset('images/meta/vereinfacht-180-180.png') }}">
<link rel="manifest" href="{{ URL::asset('manifest.json') }}">
