@if($membershipTypes->count() > 0)
    <hr class="divider">
    <div class="form__field">
        <label class="form__label" for="membership_type">Mitgliedschaft</label>
        <div class="form__select-wrap">
            <select class="form__select form__select--change-views" id="membership_type" name="membership[membership_type]" required="required">
                @foreach($membershipTypes as $membershipType)
                    @if($membershipType->accountingPeriods->count())
                        <option value="{{ $membershipType->id }}" data-view-group="membership-type" data-view-key="{{ $membershipType->id }}" @if(isset($member->membership->membershipType->id) && $member->membership->membershipType->id === $membershipType->id) selected @endif>
                            {{ $membershipType->title }}
                        </option>
                    @endif
                @endforeach
            </select>
        </div>
    </div>
    @foreach($membershipTypes as $membershipType)
        @if($membershipType->accountingPeriods->count())
            <div class="form__view" data-view-group="membership-type" data-view-key="{{ $membershipType->id }}">
                <div class="form__field">
                    <label class="form__label" for="accounting_period">Abrechnungszeitraum</label>
                    <div class="form__select-wrap">
                        <select class="form__select" id="accounting_period" name="membership[accounting_period]" required="required">
                            @foreach($membershipType->accountingPeriods as $accountingPeriod)
                                <option value="{{ $accountingPeriod->id }}" @if(isset($member->membership->accountingPeriod->id) && $member->membership->accountingPeriod->id === $accountingPeriod->id) selected @endif>{{ $accountingPeriod->title }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
        @endif
    @endforeach
    <div class="form__field">
        <label class="form__label" for="additional_fee">Freiwilliger Extrabeitrag</label>
        <input class="form__input" id="additional_fee" type="number" step="0.01" min="0" name="membership[additional_amount]" value="{{ old('additional_fee', isset($member->membership->additional_fee) ? $member->membership->additional_fee : '') }}">
    </div>
    @if ($errors->has('additional_fee'))
        <small class="error">{{ $errors->first('additional_fee') }}</small>
    @endif
@endif
