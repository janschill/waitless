<div class="form__field">
    <label class="form__label">Typ</label>
    <div class="form__select-wrap">
        <select class="form__select form__select--change-views" name="memberable_type" required="required">
            <option value="{{ \VV\Verein\Member::TYPE_PERSON }}" data-view-group="memberable-type" data-view-key="{{ \VV\Verein\Member::TYPE_PERSON }}" @if(isset($member->memberable_type) && $member->memberable_type === \VV\Verein\Member::TYPE_ORGANISATION) selected @endif>
                Person
            </option>
            <option value="{{ \VV\Verein\Member::TYPE_ORGANISATION }}" data-view-group="memberable-type" data-view-key="{{ \VV\Verein\Member::TYPE_ORGANISATION }}" @if(isset($member->memberable_type) && $member->memberable_type === \VV\Verein\Member::TYPE_ORGANISATION) selected @endif>
                Verein/Firma/Organisation
            </option>
        </select>
    </div>
</div>
<div class="form__view" data-view-group="memberable-type" data-view-key="{{ \VV\Verein\Member::TYPE_PERSON }}">
    <div class="form__field">
        <label class="form__label" for="first_name">Vorname</label>
        <input class="form__input" id="first_name" type="text" name="first_name" value="{{ old('first_name', isset($member->memberable->first_name) ? $member->memberable->first_name : '') }}" required="required">
    </div>
    @if ($errors->has('first_name'))
        <small class="error">{{ $errors->first('first_name') }}</small>
    @endif
    <div class="form__field">
        <label class="form__label" for="last_name">Nachname</label>
        <input class="form__input" id="last_name" type="text" name="last_name" value="{{ old('last_name', isset($member->memberable->last_name) ? $member->memberable->last_name : '') }}" required="required">
    </div>
    @if ($errors->has('last_name'))
        <small class="error">{{ $errors->first('last_name') }}</small>
    @endif
    <div class="form__field">
        <label class="form__label" for="nickname">Spitzname</label>
        <input class="form__input" id="nickname" type="text" name="nickname" value="{{ old('nickname', isset($member->memberable->nickname) ? $member->memberable->nickname : '') }}">
    </div>
    @if ($errors->has('nickname'))
        <small class="error">{{ $errors->first('nickname') }}</small>
    @endif
    <div class="form__field">
        <label class="form__label" for="birthday">Geburtstag</label>
        <input class="form__input" id="birthday" type="date" name="birthday" value="{{ old('birthday', isset($member->memberable->birthday) ? $member->memberable->birthday->format('Y-m-d') : '') }}">
    </div>
    @if ($errors->has('birthday'))
        <small class="error">{{ $errors->first('birthday') }}</small>
    @endif
</div>
<div class="form__view" data-view-group="memberable-type" data-view-key="{{ \VV\Verein\Member::TYPE_ORGANISATION }}">
    <div class="form__field">
        <label class="form__label" for="name">Name</label>
        <input class="form__input" id="name" type="text" name="name" value="{{ old('name', isset($member->memberable->name) ? $member->memberable->name : '') }}" required="required">
    </div>
    @if ($errors->has('name'))
        <small class="error">{{ $errors->first('name') }}</small>
    @endif
    <div class="form__field">
        <label class="form__label" for="contact_person">Kontaktperson</label>
        <input class="form__input" id="contact_person" type="text" name="contact_person" value="{{ old('contact_person', isset($member->memberable->contact_person) ? $member->memberable->contact_person : '') }}">
    </div>
    @if ($errors->has('contact_person'))
        <small class="error">{{ $errors->first('contact_person') }}</small>
    @endif
    <div class="form__field">
        <label class="form__label" for="founded">Gründung</label>
        <input class="form__input" id="founded" type="date" name="founded" value="{{ old('founded', isset($member->memberable->founded) ? $member->memberable->founded->format('Y-m-d') : '') }}">
    </div>
    @if ($errors->has('founded'))
        <small class="error">{{ $errors->first('founded') }}</small>
    @endif
</div>
<hr class="divider">
<div class="form__field">
    <label class="form__label" for="street">Straße</label>
    <input class="form__input" id="street" type="text" name="street" value="{{ old('street', isset($member->street) ? $member->street : '') }}">
</div>
@if ($errors->has('street'))
    <small class="error">{{ $errors->first('street') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="postal_code">PLZ</label>
    <input class="form__input" id="postal_code" type="text" name="postal_code" value="{{ old('postal_code', isset($member->postal_code) ? $member->postal_code : '') }}">
</div>
@if ($errors->has('postal_code'))
    <small class="error">{{ $errors->first('postal_code') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="city">Stadt/Ort</label>
    <input class="form__input" id="city" type="text" name="city" value="{{ old('city', isset($member->city) ? $member->city : '') }}">
</div>
@if ($errors->has('city'))
    <small class="error">{{ $errors->first('city') }}</small>
@endif
<hr class="divider">
<div class="form__field">
    <label class="form__label" for="email">E-Mail-Adresse</label>
    <input class="form__input" id="email" type="email" name="email" value="{{ old('email', isset($member->email) ? $member->email : '') }}" required="required">
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="telephone">Telefonnummer</label>
    <input class="form__input" id="telephone" type="text" name="telephone" value="{{ old('telephone', isset($member->telephone) ? $member->telephone : '') }}">
</div>
@if ($errors->has('telephone'))
    <small class="error">{{ $errors->first('telephone') }}</small>
@endif
<hr class="divider">
<div class="form__field">
    <label class="form__label" for="member_number">Mitgliedsnummer</label>
    <input class="form__input" id="member_number" type="text" name="member_number" value="{{ old('member_number', isset($member->member_number) ? $member->member_number : '') }}">
</div>
@if ($errors->has('member_number'))
    <small class="error">{{ $errors->first('member_number') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="avatar">Profilbild</label>
    <input class="form__input" id="avatar" type="file" name="avatar">
</div>
@if ($errors->has('avatar'))
    <small class="error">{{ $errors->first('avatar') }}</small>
@endif
@if(isset($member->avatar))
    <img class="form__image" src="{{ asset('storage/uploads/' . $member->avatar) }}">
@endif
<div class="form__field">
    <label class="form__label" for="member_since">Eintrittsdatum</label>
    <input class="form__input" id="member_since" type="date" name="member_since" value="{{ old('member_since', isset($member->member_since) ? $member->member_since->format('Y-m-d') : '') }}">
</div>
@if ($errors->has('member_since'))
    <small class="error">{{ $errors->first('member_since') }}</small>
@endif
<div class="form__field form__field--large">
    <label class="form__label" for="notes">Notizen</label>
    <textarea class="form__textarea" id="notes" name="notes">{{ old('notes', isset($member->notes) ? $member->notes : '') }}</textarea>
</div>
@if ($errors->has('notes'))
    <small class="error">{{ $errors->first('notes') }}</small>
@endif
