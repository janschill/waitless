@if($memberProperties->count())
    @foreach($memberProperties as $increment => $memberProperty)
        @if($memberProperty->type === \VV\Verein\MemberProperty::TYPE_SELECT && $memberProperty->memberPropertyValues()->count())
            <div class="form__field">
                <label class="form__label">{{ $memberProperty->title }}</label>
                <input type="hidden" name="member_property_value_relations[{{ $increment }}][member_property_id]" value="{{$memberProperty->id}}">
                <div class="form__select-wrap">
                    <select class="form__select" name="member_property_value_relations[{{ $increment }}][member_property_value]">
                        <option selected value="">Bitte auswählen</option>
                        @foreach($memberProperty->memberPropertyValues as $memberPropertyValue)
                            <option value="{{ $memberPropertyValue->id }}" @if($member && $member->isMemberPropertyRelated($memberProperty->id, $memberPropertyValue->id)) selected @endif>
                                {{ $memberPropertyValue->value }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
        @endif
        @if($memberProperty->type === \VV\Verein\MemberProperty::TYPE_INPUT)
            <div class="form__field">
                <label class="form__label">{{ $memberProperty->title }}</label>
                <input type="hidden" name="member_property_value_relations[{{ $increment }}][member_property_id]" value="{{$memberProperty->id}}">
                <input class="form__input" type="text" name="member_property_value_relations[{{ $increment }}][member_property_value]" value="@if($member){{$member->getRelatedMemberPropertyValue($memberProperty)}}@endif">
            </div>
        @endif
    @endforeach
@endif
