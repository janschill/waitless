<article class="card">
    @switch($notification->type)
        @case('VV\Verein\Notifications\MemberStored')
            <figure class="card__figure card__figure--positive">
                <span class="card__icon">
                    @include('default.partials.icons.members')
                </span>
            </figure>
            @break
        @case('VV\Verein\Notifications\MemberDestroyed')
            <figure class="card__figure card__figure--negative">
                <span class="card__icon">
                    @include('default.partials.icons.members')
                </span>
            </figure>
            @break
        @default
            <figure class="card__figure">
                <span class="card__icon">
                    @include('default.partials.icons.members')
                </span>
            </figure>
    @endswitch
    <time class="card__time" datetime="{{ \Carbon\Carbon::parse($notification->created_at)->format('r') }}">
        {{ \Carbon\Carbon::parse($notification->created_at)->format('d.m.Y') }}
    </time>
    <h4 class="headline headline--unobtrusive">{{ $notification->data['headline'] }}</h4>
    <p class="paragraph">{{ $notification->data['text'] }}</p>
</article>
