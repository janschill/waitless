<div class="form__field">
    <label class="form__label" for="title">Titel</label>
    <input class="form__input" id="title" type="text" name="title" value="{{ old('title', isset($memberProperty->title) ? $memberProperty->title : '') }}" required="required">
</div>
@if ($errors->has('name'))
    <small class="error">{{ $errors->first('title') }}</small>
@endif
