@if(Auth::user()->clubs()->count() > 1)
    <article class="article">
        <h2 class="headline">
            Verein <strong class="strong">wechseln</strong>
        </h2>
        <form class="switch" action="{{action('Backend\DashboardController@switchClub')}}" method="POST">
            @if(isset($club->logo))
                <img class="switch__image" src="{{ asset('storage/uploads/' . $club->logo) }}" alt="{{ $club->name }}" width="32">
            @else
                <img class="switch__image" src="{{ URL::asset('images/mask.svg') }}" alt="{{ $club->name }}" width="32">
            @endif
            {{ csrf_field() }}
            <select class="switch__select" name="club_id">
                @foreach(Auth::user()->clubs as $userClub)
                    <option value="{{ $userClub->id }}" @if($userClub->id === $club->id) selected @endif>{{ $userClub->name }}</option>
                @endforeach
            </select>
        </form>
    </article>
@endif
<article class="article article--important">
    <h2 class="headline">
        {{ config('app.name') }} <strong class="strong">gefällt dir</strong>?
    </h2>
    <p class="paragraph">Dann würden wir uns über eine Weiterempfehlung an andere Vereine freuen.</p>
    <a class="link" href="mailto:?subject={{ config('app.name') }}&body=Wir nutzen für unsere Vereinsverwaltung die Webanwendung ›{{ config('app.name') }}‹ und empfehlen diese gern weiter. Vielleicht ist so eine Software für euch auch interessant? {{URL::to('?referral=' . $club->id)}}">
        <span class="link__icon">@include('default.partials.icons.arrowRight')</span>Weiterempfehlen
    </a>
</article>
<article class="article">
    <figure class="article__figure article__figure--no-spacing">
        <img class="article__image" src="{{ URL::asset('images/support.jpg') }}" alt="Guter Support von vereinfacht">
    </figure>
    <h2 class="headline">Wir sind <strong class="strong">für dich</strong> da</h2>
    <p class="paragraph">Das Team von {{ config('app.name') }} steht dir zur Seite. Uns liegt deine Zufriedenheit wirklich am Herzen – also scheue nicht uns bei Fragen zu kontaktieren:</p>
    <p class="paragraph">
        <a class="link" href="{{action('Corporate\ContentController@about')}}">Mehr über uns</a>
    </p>
    <address class="address">
        <a class="link" href="tel:+4946115065366">0461 15065366</a><br>
        <a class="link" href="mailto:hallo@vereinfacht.digital">hallo@vereinfacht.digital</a><br>
    </address>
    <ul class="list-unobtrusive">
        <li class="list-unobtrusive__item">
            <a class="link link--unobtrusive" target="_blank" href="https://www.facebook.com/Vereinfacht-136938837139411/">Facebook</a>
        </li>
        <li class="list-unobtrusive__item">
            <a class="link link--unobtrusive" target="_blank" href="https://twitter.com/vereinfacht_">Twitter</a>
        </li>
        <li class="list-unobtrusive__item">
            <a class="link link--unobtrusive" target="_blank" href="https://www.instagram.com/vereinfacht/">Instagram</a>
        </li>
    </ul>
</article>
<article class="unobtrusive">
    <small class="small">@motto</small>
</article>
