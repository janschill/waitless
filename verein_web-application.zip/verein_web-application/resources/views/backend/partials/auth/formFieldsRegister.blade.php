<div class="form__field">
    <label class="form__label" for="first_name">Vorname</label>
    <input class="form__input" id="first_name" type="text" name="first_name" value="{{ old('first_name') }}" required="required">
</div>
@if ($errors->has('first_name'))
    <small class="error">{{ $errors->first('first_name') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="last_name">Nachname</label>
    <input class="form__input" id="last_name" type="text" name="last_name" value="{{ old('last_name') }}" required="required">
</div>
@if ($errors->has('last_name'))
    <small class="error">{{ $errors->first('last_name') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="email_register">E-Mail-Adresse</label>
    <input class="form__input" id="email_register" type="email" name="email" value="{{ old('email') }}" required="required">
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="password_register">Passwort</label>
    <input class="form__input" id="password_register" type="password" name="password" required="required">
</div>
@if ($errors->has('password'))
    <small class="error">{{ $errors->first('password') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="password_register_confirmation">Passwort bestätigen</label>
    <input class="form__input" id="password_register_confirmation" type="password" name="password_confirmation" required="required">
</div>
@if ($errors->has('password_confirmation'))
    <small class="error">{{ $errors->first('password_confirmation') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="club_name">Name des Vereins</label>
    <input class="form__input" id="club_name" type="text" name="club[name]" value="{{ old('club[name]') }}">
</div>
@if ($errors->has('club_name'))
    <small class="error">{{ $errors->first('club_name') }}</small>
@endif
@if(request('referral'))
    <input type="hidden" name="club[referral_id]" value="{{request('referral')}}">
@endif
