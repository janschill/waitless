<div class="form__field">
    <label class="form__label" for="email">E-Mail-Adresse</label>
    <input class="form__input" id="email" type="email" name="email" value="{{ old('email') }}" required="required">
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="password">Passwort</label>
    <input class="form__input" id="password" type="password" name="password" required="required">
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
