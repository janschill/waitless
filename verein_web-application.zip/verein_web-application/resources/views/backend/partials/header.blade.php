<header class="header">
    <div class="header__wrap">
        @include('backend.partials.navigationMain')
        @include('backend.partials.teaserUser')
    </div>
</header>
