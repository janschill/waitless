<div class="form__field">
    <label class="form__label" for="subject">Betreff</label>
    <input class="form__input" id="subject" type="text" name="subject" value="{{ old('subject', isset($mailing->subject) ? $mailing->subject : '') }}" required="required">
</div>
@if ($errors->has('subject'))
    <small class="error">{{ $errors->first('subject') }}</small>
@endif
<div class="form__field form__field--x-large">
    <label class="form__label" for="text">Text</label>
    <textarea class="form__textarea" id="text" name="text">{{ old('text', isset($mailing->text) ? $mailing->text : '') }}</textarea>
</div>
@if ($errors->has('text'))
    <small class="error">{{ $errors->first('text') }}</small>
@endif
