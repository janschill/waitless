<aside class="teaser-user">
    <form class="teaser-user__form" action="{{ action('Backend\Auth\LoginController@logout') }}" method="POST">
        {{ csrf_field() }}
        <span class="teaser-user__link">
            <button class="button-reset" type="submit">Logout</button>
            <span class="teaser-user__icon">@include('default.partials.icons.out')</span>
        </span>
    </form>
    <div class="teaser-user__item">
        <a class="teaser-user__link" href="{{ action('Backend\UserController@edit') }}">
            Moin {{ Auth::user()->first_name }}!
            <span class="teaser-user__icon">@include('default.partials.icons.pencil')</span>
        </a>
        <div class="teaser-user__sub">
            @include('backend.partials.navigationSub.profile', ['cssModifierClasses' => 'navigation-sub--header'])
        </div>
    </div>
    @if(Auth::user()->avatar)
        <figure class="teaser-user__figure">
            <a href="{{ action('Backend\UserController@edit') }}">
                <img class="teaser-user__image" src="{{asset('storage/uploads/' . Auth::user()->avatar)}}">
            </a>
        </figure>
    @endif
</aside>
