<footer class="footer">
    <figure class="footer__logo">
        <a href="{{action('Backend\DashboardController@index')}}">
            <img width="200" src="/images/vereinfacht.svg" alt="{{ config('app.name') }}">
        </a>
    </figure>
    <section class="footer__additional">
        <a class="link link--bright" href="https://www.visuellverstehen.de/" target="_blank">visuellverstehen</a> — <a class="link link--bright" href="{{ action('Corporate\ContentController@imprint') }}">Impressum</a><br>
        <small class="small">{{ config('app.name') }} – {{ env('APP_ENV') }}</small>
    </section>
</footer>
