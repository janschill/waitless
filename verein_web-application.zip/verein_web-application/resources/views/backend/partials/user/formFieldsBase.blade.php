<div class="form__field">
    <label class="form__label" for="first_name">Vorname</label>
    <input class="form__input" id="first_name" type="text" name="first_name" value="{{ old('first_name', isset($user->first_name) ? $user->first_name : '') }}" required="required">
</div>
@if ($errors->has('first_name'))
    <small class="error">{{ $errors->first('first_name') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="last_name">Vorname</label>
    <input class="form__input" id="last_name" type="text" name="last_name" value="{{ old('last_name', isset($user->last_name) ? $user->last_name : '') }}" required="required">
</div>
@if ($errors->has('last_name'))
    <small class="error">{{ $errors->first('last_name') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="email">E-Mail-Adresse</label>
    <input class="form__input" id="email" type="email" name="email" value="{{ old('email', isset($user->email) ? $user->email : '') }}" required="required">
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="avatar">Profilbild</label>
    <input class="form__input" id="avatar" type="file" name="avatar">
</div>
@if ($errors->has('avatar'))
    <small class="error">{{ $errors->first('avatar') }}</small>
@endif
@if(isset($user->avatar))
    <img class="form__image" src="{{ asset('storage/uploads/' . $user->avatar) }}">
@endif
