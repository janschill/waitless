<nav class="navigation-main">
    <ul class="navigation-main__list">
        <li class="navigation-main__item @if(strpos(request()->route()->getActionName(), 'DashboardController')) navigation-main__item--active @endif">
            <a class="navigation-main__link" href="{{action('Backend\DashboardController@index')}}">
                <span class="navigation-main__icon">
                    @include('default.partials.icons.tiles')
                </span>
                Dashboard
            </a>
            <div class="navigation-main__sub">
                @include('backend.partials.navigationSub.dashboard', ['cssModifierClasses' => 'navigation-sub--header'])
            </div>
        </li>
        <li class="navigation-main__item @if(strpos(request()->route()->getActionName(), 'MemberController')) navigation-main__item--active @endif">
            <a class="navigation-main__link" href="{{action('Backend\MemberController@index')}}">
                <span class="navigation-main__icon">
                    @include('default.partials.icons.members')
                </span>
                Mitglieder
            </a>
            <div class="navigation-main__sub">
                @include('backend.partials.navigationSub.members', ['cssModifierClasses' => 'navigation-sub--header'])
            </div>
        </li>
        <li class="navigation-main__item @if(strpos(request()->route()->getActionName(), 'MailingController')) navigation-main__item--active @endif">
            <a class="navigation-main__link" href="{{action('Backend\MailingController@index')}}">
                <span class="navigation-main__icon">
                    @include('default.partials.icons.letter')
                </span>
                Mailings
            </a>
            <div class="navigation-main__sub">
                @include('backend.partials.navigationSub.mailing', ['cssModifierClasses' => 'navigation-sub--header'])
            </div>
        </li>
        <li class="navigation-main__item @if(strpos(request()->route()->getActionName(), 'ClubController@edit')) navigation-main__item--active @endif">
            <a class="navigation-main__link" href="{{action('Backend\ClubController@edit')}}">
                <span class="navigation-main__icon">
                    @include('default.partials.icons.gear')
                </span>
                Einstellungen
            </a>
            <div class="navigation-main__sub">
                @include('backend.partials.navigationSub.settings', ['cssModifierClasses' => 'navigation-sub--header'])
            </div>
        </li>
    </ul>
</nav>
