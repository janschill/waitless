<nav class="navigation-sub {{ isset($cssModifierClasses) ? $cssModifierClasses : '' }}">
    <ul class="navigation-sub__list-level-1">
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Übersicht</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'DashboardController@index')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\DashboardController@index')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.tiles')
                        </span>
                        Dashboard
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'DashboardController@notifications')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\DashboardController@notifications')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.bell')
                        </span>
                        Benachrichtigungen
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'DashboardController@statistics')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\DashboardController@statistics')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.chartBar')
                        </span>
                        Statistiken
                    </a>
                </li>
            </ul>
        </li>
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Erstellen</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\MemberController@create')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.memberCreate')
                        </span>
                        Neues Mitglied
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'Backend\ClubController@createNotification')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@createNotification')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.create')
                        </span>
                        Neue Benachrichtigung
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
