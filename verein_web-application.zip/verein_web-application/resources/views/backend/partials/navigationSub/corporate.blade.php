<nav class="navigation-sub {{ isset($cssModifierClasses) ? $cssModifierClasses : '' }}">
    <ul class="navigation-sub__list-level-1">
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">{{ config('app.name') }}</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ContentController@about')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Corporate\ContentController@about')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.tiles')
                        </span>
                        Über uns
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ContentController@imprint')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Corporate\ContentController@imprint')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.bell')
                        </span>
                        Impressum
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
