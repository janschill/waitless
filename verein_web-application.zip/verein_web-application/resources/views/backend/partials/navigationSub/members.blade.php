<nav class="navigation-sub {{ isset($cssModifierClasses) ? $cssModifierClasses : '' }}">
    <ul class="navigation-sub__list-level-1">
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Mitglieder</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'MemberController@index')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\MemberController@index')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.members')
                        </span>
                        Alle Mitglieder
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@birthdays')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@birthdays')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.box')
                        </span>
                        Geburtstage
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@anniversaries')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@anniversaries')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.award')
                        </span>
                        Jubiläen
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ExportController@index')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ExportController@index')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.out')
                        </span>
                        Exportieren
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'MemberController@create')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\MemberController@create')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.memberCreate')
                        </span>
                        Neues Mitglied
                    </a>
                </li>
            </ul>
        </li>
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Mitgliedschaften</h3>
            <ul class="navigation-sub__list-level-2">
                @foreach($club->membershipTypes as $membershipType)
                    <li class="navigation-sub__item-level-2">
                        <a class="navigation-sub__link-level-2 navigation-sub__link-level-2--without-icon" href="{{action('Backend\MembershipTypeController@edit', ['membershipType' => $membershipType])}}">{{ $membershipType->title }}</a>
                    </li>
                @endforeach
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'MembershipTypeController@create')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{ action('Backend\MembershipTypeController@create') }}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.create')
                        </span>
                        Neue Mitgliedschaft
                    </a>
                </li>
            </ul>
        </li>
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Eigenschaften</h3>
            <ul class="navigation-sub__list-level-2">
                @foreach($club->memberProperties as $memberProperty)
                    <li class="navigation-sub__item-level-2">
                        <a class="navigation-sub__link-level-2 navigation-sub__link-level-2--without-icon" href="{{ action('Backend\MemberPropertyController@edit', ['memberProperty' => $memberProperty]) }}">{{ $memberProperty->title }}</a>
                    </li>
                @endforeach
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'MemberPropertyController@create')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\MemberPropertyController@create')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.create')
                        </span>
                        Neue Eigenschaft
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
