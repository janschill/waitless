<nav class="navigation-sub {{ isset($cssModifierClasses) ? $cssModifierClasses : '' }}">
    <ul class="navigation-sub__list-level-1">
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Verein</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@edit')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@edit')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.pencil')
                        </span>
                        Bearbeiten
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@indexUser')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@indexUser')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.members')
                        </span>
                        Benutzer verwalten
                    </a>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@remove')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{action('Backend\ClubController@remove')}}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.cross')
                        </span>
                        Löschen
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
