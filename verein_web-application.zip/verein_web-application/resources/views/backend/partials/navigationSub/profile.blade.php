<nav class="navigation-sub {{ isset($cssModifierClasses) ? $cssModifierClasses : '' }}">
    <ul class="navigation-sub__list-level-1">
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Profil</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'UserController@edit')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{ action('Backend\UserController@edit') }}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.pencil')
                        </span>
                        Bearbeiten
                    </a>
                </li>
                <li class="navigation-sub__item-level-2">
                    <form action="{{ action('Backend\Auth\LoginController@logout') }}" method="POST">
                        {{ csrf_field() }}
                        <span class="navigation-sub__link-level-2">
                            <span class="navigation-sub__icon-level-2">
                                @include('default.partials.icons.out')
                            </span>
                            <button class="button-reset" type="submit">Logout</button>
                        </span>
                    </form>
                </li>
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'UserController@remove')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{ action('Backend\UserController@remove') }}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.cross')
                        </span>
                        Löschen
                    </a>
                </li>
            </ul>
        </li>
        <li class="navigation-sub__item-level-1">
            <h3 class="headline headline--alternative">Sonstiges</h3>
            <ul class="navigation-sub__list-level-2">
                <li class="navigation-sub__item-level-2 @if(strpos(request()->route()->getActionName(), 'ClubController@create')) navigation-sub__item-level-2--active @endif">
                    <a class="navigation-sub__link-level-2" href="{{ action('Backend\ClubController@create') }}">
                        <span class="navigation-sub__icon-level-2">
                            @include('default.partials.icons.create')
                        </span>
                        Neuer Verein
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
