<div class="form__field">
    <label class="form__label" for="name">Name</label>
    <input class="form__input" id="name" type="text" name="name" value="{{ old('name', isset($club->name) ? $club->name : '') }}" required="required">
</div>
@if ($errors->has('name'))
    <small class="error">{{ $errors->first('name') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="street">Straße</label>
    <input class="form__input" id="street" type="text" name="street" value="{{ old('street', isset($club->street) ? $club->street : '') }}">
</div>
@if ($errors->has('street'))
    <small class="error">{{ $errors->first('street') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="postalCode">PLZ</label>
    <input class="form__input" id="postalCode" type="text" name="postal_code" value="{{ old('postal_code', isset($club->postal_code) ? $club->postal_code : '') }}">
</div>
@if ($errors->has('postal_code'))
    <small class="error">{{ $errors->first('postal_code') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="city">Stadt/Ort</label>
    <input class="form__input" id="city" type="text" name="city" value="{{ old('city', isset($club->city) ? $club->city : '') }}">
</div>
@if ($errors->has('city'))
    <small class="error">{{ $errors->first('city') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="website">Website</label>
    <input class="form__input" id="website" type="text" name="website" value="{{ old('website', isset($club->website) ? $club->website : '') }}">
</div>
@if ($errors->has('website'))
    <small class="error">{{ $errors->first('website') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="email">E-Mail-Adresse</label>
    <input class="form__input" id="email" type="email" name="email" value="{{ old('email', isset($club->email) ? $club->email : '') }}" required>
</div>
@if ($errors->has('email'))
    <small class="error">{{ $errors->first('email') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="founding_date">Gründungsdatum</label>
    <input class="form__input" id="founding_date" type="date" name="founding_date" value="{{ old('founding_date', isset($club->founding_date) ? $club->founding_date->format('Y-m-d') : '') }}">
</div>
@if ($errors->has('founding_date'))
    <small class="error">{{ $errors->first('founding_date') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="logo">Logo</label>
    <input class="form__input" id="logo" type="file" name="logo">
</div>
@if(isset($club->logo))
    <img class="form__image" src="{{ asset('storage/uploads/' . $club->logo) }}">
@endif
@if ($errors->has('logo'))
    <small class="error">{{ $errors->first('logo') }}</small>
@endif
