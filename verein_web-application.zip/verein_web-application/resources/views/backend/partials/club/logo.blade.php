<figure class="figure figure--logo">
    <a class="figure__link" href="{{action('Backend\ClubController@edit')}}">
        @if(isset($club->logo))
            <img class="figure__image" src="{{ asset('storage/uploads/' . $club->logo) }}" alt="{{ $club->name }}">
        @else
            <img class="figure__image" src="{{ URL::asset('images/mask.svg') }}" alt="{{ $club->name }}">
        @endif
        <figcaption class="figure__icon">
            @include('default.partials.icons.pencil')
        </figcaption>
    </a>
</figure>
