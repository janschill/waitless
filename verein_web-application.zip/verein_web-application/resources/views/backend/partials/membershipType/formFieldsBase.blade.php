<div class="form__field">
    <label class="form__label" for="title">Titel</label>
    <input class="form__input" id="title" type="text" name="title" value="{{ old('title', isset($membershipType->title) ? $membershipType->title : '') }}" required="required">
</div>
@if ($errors->has('title'))
    <small class="error">{{ $errors->first('title') }}</small>
@endif
<div class="form__field">
    <label class="form__label" for="monthly_fee">Monatlicher Beitrag</label>
    <input class="form__input" id="monthly_fee" type="number" step="0.01" min="0" name="monthly_fee" value="{{ old('monthly_fee', isset($membershipType->monthly_fee) ? $membershipType->monthly_fee : '') }}" required="required">
</div>
@if ($errors->has('monthly_fee'))
    <small class="error">{{ $errors->first('monthly_fee') }}</small>
@endif

<div class="form__field">
    <label class="form__label">Abrechnungszeiträume</label>
    @foreach($accountingPeriods as $accountingPeriod)
        <input class="form__checkbox-input" id="accountingPeriod-{{$accountingPeriod->id}}" type="checkbox" name="accounting_periods[]" value="{{$accountingPeriod->id}}" @if(isset($membershipType->accountingPeriods) && $membershipType->accountingPeriods->contains($accountingPeriod)) checked @endif>
        <label class="form__checkbox-label" for="accountingPeriod-{{$accountingPeriod->id}}">{{ $accountingPeriod->title }}</label>
    @endforeach
</div>
