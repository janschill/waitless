<figure class="chart-circle">
    <svg class="chart-circle__svg" viewBox="0 0 42 42">
        <circle class="chart-circle__background" cx="21" cy="21" r="19"></circle>
        <circle class="chart-circle__value" cx="21" cy="21" r="19" stroke-dasharray="100 0"></circle>
    </svg>
    <figcaption class="chart-circle__caption">
        pro Monat<br>
        <strong class="chart-circle__strong">{{number_format($club->getMonthlyEarnings(), 2, ',', '.')}} €</strong><br>
        Einnahmen
    </figcaption>
</figure>
