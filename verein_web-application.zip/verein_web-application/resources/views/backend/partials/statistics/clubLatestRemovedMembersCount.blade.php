<figure class="chart-circle chart-circle--negative">
    <svg class="chart-circle__svg" viewBox="0 0 42 42">
        <circle class="chart-circle__background" cx="21" cy="21" r="19"></circle>
        <circle class="chart-circle__value" cx="21" cy="21" r="19" stroke-dasharray="{{$club->ratioBetweenRemovedAndNewMembers()}} {{$club->ratioBetweenNewAndRemovedMembers()}}"></circle>
    </svg>
    <figcaption class="chart-circle__caption">
        7 Tage<br>
        <strong class="chart-circle__strong">{{ $club->countLatestRemovedMembers() }}</strong><br>
        Gelöschte Mitglieder
    </figcaption>
</figure>
