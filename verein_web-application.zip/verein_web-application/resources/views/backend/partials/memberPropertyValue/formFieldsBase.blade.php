<div class="form__field">
    <label class="form__label" for="value">Wert</label>
    <input class="form__input" id="value" type="text" name="value" value="{{ old('value', isset($memberPropertyValue->value) ? $memberPropertyValue->value : '') }}" required="required">
</div>
@if ($errors->has('name'))
    <small class="error">{{ $errors->first('value') }}</small>
@endif
