<!DOCTYPE html>
<html class="html html--backend" lang="{{ config('app.locale') }}">
    <head>
        @include('backend.partials.head')
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('stylesheets/app.min.css') }}?v={{time()}}" media="all" />
    </head>
    <body class="body body--backend">
        @include('default.partials.browseHappy')
        @include('backend.partials.header')
        <main class="main">
            <div class="main__wrap">
                <aside class="main__menu">
                    @yield('mainMenu')
                </aside>
                <section class="main__content">
                    @yield('mainContent')
                </section>
                <aside class="main__sidebar">
                    @include('backend.partials.sidebar')
                    @yield('mainSidebar')
                </aside>
            </div>
        </main>
        @include('backend.partials.footer')
        <script type="text/javascript" src="{{ URL::asset('javascripts/app.min.js') }}?v={{time()}}"></script>
        <script type="text/javascript" src="https://embed.small.chat/T03C9RPCZG9LGQEY0K.js" async></script>
    </body>
</html>
