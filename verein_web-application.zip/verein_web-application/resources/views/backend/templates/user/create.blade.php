@extends('backend.layouts.default')

@section('pageTitle', 'Neuer Benutzer')
@section('mainMenu')
    @include('backend.partials.menu.settings')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\UserController@store') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neuer Benutzer</strong>
                </legend>
                <div class="form__field">
                    <label class="form__label" for="first_name">Vorname</label>
                    <input class="form__input" id="first_name" type="text" name="first_name" value="{{ old('first_name') }}" required="required">
                </div>
                @if ($errors->has('first_name'))
                    <small class="error">{{ $errors->first('first_name') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="last_name">Nachname</label>
                    <input class="form__input" id="last_name" type="text" name="last_name" value="{{ old('last_name') }}" required="required">
                </div>
                @if ($errors->has('last_name'))
                    <small class="error">{{ $errors->first('last_name') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="email_register">E-Mail-Adresse</label>
                    <input class="form__input" id="email_register" type="email" name="email" value="{{ old('email') }}" required="required">
                </div>
                @if ($errors->has('email'))
                    <small class="error">{{ $errors->first('email') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="password_register">Passwort</label>
                    <input class="form__input" id="password_register" type="password" name="password" required="required">
                </div>
                @if ($errors->has('password'))
                    <small class="error">{{ $errors->first('password') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="password_register_confirmation">Passwort bestätigen</label>
                    <input class="form__input" id="password_register_confirmation" type="password" name="password_confirmation" required="required">
                </div>
                @if ($errors->has('password_confirmation'))
                    <small class="error">{{ $errors->first('password_confirmation') }}</small>
                @endif
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.disk')</span>
                    Speichern
                </button>
            </fieldset>
        </form>
    </article>
@endsection
