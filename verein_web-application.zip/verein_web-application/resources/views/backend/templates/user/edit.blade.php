@extends('backend.layouts.default')

@section('pageTitle', 'Benutzer bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.profile')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\UserController@update') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $user->first_name }} {{ $user->last_name }}</strong>
                </legend>
                @include('backend.partials.user.formFieldsBase')
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.disk')</span>
                    Speichern
                </button>
            </fieldset>
        </form>
    </article>
@endsection
