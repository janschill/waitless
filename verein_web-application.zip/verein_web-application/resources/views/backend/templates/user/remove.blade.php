@extends('backend.layouts.default')

@section('pageTitle', 'Benutzer löschen')
@section('mainMenu')
    @include('backend.partials.menu.profile')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\UserController@destroy')}}" method="POST">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $user->first_name }} {{ $user->last_name }}</strong>
                </legend>
                <legend class="paragraph">
                    Den Benutzer "{{ $user->first_name }} {{ $user->last_name }}" jetzt löschen.
                </legend>
                <button class="button button--negative" type="submit">
                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                    Löschen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
