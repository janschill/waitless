@extends('corporate.layouts.default')

@section('pageTitle', 'Neues Passwort')
@section('mainContent')
    <article class="article">
        <form class="form" method="POST" action="{{ action('Backend\Auth\ResetPasswordController@reset') }}">
            {{ csrf_field() }}
            <input type="hidden" name="token" value="{{ $token }}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neues Passwort</strong>
                </legend>
                <div class="form__field">
                    <label class="form__label" for="email">E-Mail-Adresse</label>
                    <input class="form__input" id="email" type="email" name="email" value="{{ old('email') }}" required="required">
                </div>
                @if ($errors->has('email'))
                    <small class="error">{{ $errors->first('email') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="password">Passwort</label>
                    <input class="form__input" id="password" type="password" name="password" required="required">
                </div>
                @if ($errors->has('password'))
                    <small class="error">{{ $errors->first('password') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="password_confirmation">Passwort bestätigen</label>
                    <input class="form__input" id="password_confirmation" type="password" name="password_confirmation" required="required">
                </div>
                @if ($errors->has('password_confirmation'))
                    <small class="error">{{ $errors->first('password_confirmation') }}</small>
                @endif
               <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.arrowRight')</span>
                    Zurücksetzen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
