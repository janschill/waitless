@extends('corporate.layouts.default')

@section('pageTitle', 'Passwort zurücksetzen')
@section('mainContent')
    <article class="article">
        <figure class="figure figure--spacing">
            <img class="figure__image" src="{{ URL::asset('images/icons/register.svg') }}" alt="Registrieren">
        </figure>
        <form class="form" method="POST" action="{{ action('Backend\Auth\ForgotPasswordController@sendResetLinkEmail') }}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Passwort zurücksetzen</strong>
                </legend>
                {{ csrf_field() }}
                <div class="form__field">
                    <label class="form__label" for="email">E-Mail-Adresse</label>
                    <input class="form__input" id="email" type="text" name="email" email="{{ old('email') }}" required="required">
                </div>
                @if ($errors->has('email'))
                    <small class="error">{{ $errors->first('email') }}</small>
                @endif
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.arrowRight')</span>
                    Zurücksetzen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
