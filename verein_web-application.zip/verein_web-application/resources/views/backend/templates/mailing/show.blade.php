@extends('backend.layouts.default')

@section('pageTitle', 'Mailing anzeigen')
@section('mainMenu')
    @include('backend.partials.menu.mailing')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">{{ $mailing->subject }}</strong>
        </h1>
        <p class="paragraph">Verschickt am <time datetime="{{ \Carbon\Carbon::parse($mailing->created_at)->format('r') }}">{{ $mailing->created_at->format('d.m.Y H:i') }} Uhr</time></p>
        <hr class="divider">
        <p class="paragraph">{!! nl2br(e($mailing->text)) !!}</p>
    </article>
@endsection
