@extends('backend.layouts.default')

@section('pageTitle', 'Mailings')
@section('mainMenu')
    @include('backend.partials.menu.mailing')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Mailings</strong>
        </h1>
        @if($mailings->count())
            <section class="overview overview--searchable" data-placeholder="Suche …" data-no-rows="Keine Mailings gefunden. <a class='link' href='{{ action('Backend\MailingController@create') }}'>Neues Mailing</a> erstellen." data-info="{start}–{end} von {rows} Mailings">
                <table class="overview__table">
                    <thead class="overview__header">
                        <tr class="overview__row">
                            <th class="overview__cell">ID</th>
                            <th class="overview__cell">Betreff</th>
                            <th class="overview__cell">Datum</th>
                            <th class="overview__cell"></th>
                            <th class="overview__cell"></th>
                        </tr>
                    </thead>
                    @foreach($mailings as $mailing)
                        <tr class="overview__row">
                            <td class="overview__cell">
                                {{ $mailing->id }}
                            </td>
                            <td class="overview__cell">
                                {{ $mailing->subject }}
                            </td>
                            <td class="overview__cell">
                                <time datetime="{{ \Carbon\Carbon::parse($mailing->created_at)->format('r') }}">{{ $mailing->created_at->format('d.m.Y H:i') }} Uhr</time>
                            </td>
                            <td class="overview__cell overview__cell--fit-to-content">
                                <a class="button button--primary" href="{{ action('Backend\MailingController@show', ['mailing' => $mailing]) }}">
                                    <span class="button__icon">@include('default.partials.icons.chartLine')</span>
                                    Status
                                </a>
                            </td>
                            <td class="overview__cell overview__cell--fit-to-content">
                                <a class="button button--primary" href="{{ action('Backend\MailingController@preview', ['mailing' => $mailing]) }}" target="_blank">
                                    <span class="button__icon">@include('default.partials.icons.eye')</span>
                                    Vorschau
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </table>
            </section>
        @else
            <p class="paragraph">Bisher wurden keine Mailings erstellt.</p>
            <a class="button button--primary" href="{{ action('Backend\MailingController@create') }}">
                <span class="button__icon">@include('default.partials.icons.create')</span>
                Mailing erstellen
            </a>
        @endif
    </article>
@endsection
