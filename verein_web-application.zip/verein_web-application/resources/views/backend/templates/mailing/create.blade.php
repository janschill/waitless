@extends('backend.layouts.default')

@section('pageTitle', 'Neues Mailing')
@section('mainMenu')
    @include('backend.partials.menu.mailing')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\MailingController@store')}}" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="mail_type" value="{{\VV\Verein\Mail\Club::class}}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neues Mailing</strong>
                </legend>
                <p class="paragraph">Erstelle ein Mailing und sende es automatisch an alle Mitglieder.</p>
                @include('backend.partials.mailing.formFieldsBase', ['mailing' => null])
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    An alle Mitglieder senden
                </button>
            </fieldset>
        </form>
    </article>
@endsection
