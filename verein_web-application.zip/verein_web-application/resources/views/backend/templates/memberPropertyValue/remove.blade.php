@extends('backend.layouts.default')

@section('pageTitle', 'Eigenschaftswert löschen')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberPropertyValueController@destroy', ['memberPropertyValue' => $memberPropertyValue]) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $memberPropertyValue->value }}</strong>
                </legend>
                <p class="paragraph">
                    Den Eigenschaftswert "{{ $memberPropertyValue->value }}" jetzt löschen.
                </p>
                <button class="button button--negative" type="submit">
                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                    Löschen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
