@extends('backend.layouts.default')

@section('pageTitle', 'Eigenschaftswert bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\MemberPropertyValueController@update', ['memberPropertyValue' => $memberPropertyValue])}}" method="POST">
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $memberPropertyValue->value }}</strong>
                </legend>
                @include('backend.partials.memberPropertyValue.formFieldsBase')
                <ul class="button-list">
                    <li class="button-list__item">
                        <button class="button button--primary" type="submit">
                            <span class="button__icon">@include('default.partials.icons.disk')</span>
                            Speichern
                        </button>
                    </li>
                    <li class="button-list__item">
                        <a class="button button--negative" href="{{ action('Backend\MemberPropertyValueController@remove', ['memberPropertyValue' => $memberPropertyValue]) }}">
                            <span class="button__icon">@include('default.partials.icons.cross')</span>
                            Löschen
                        </a>
                    </li>
                </ul>
            </fieldset>
        </form>
    </article>
@endsection
