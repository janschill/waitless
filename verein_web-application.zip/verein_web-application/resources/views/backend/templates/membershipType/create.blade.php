@extends('backend.layouts.default')

@section('pageTitle', 'Neue Mitgliedschaft')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\MembershipTypeController@store')}}" method="POST">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neue Mitgliedschaft</strong>
                </legend>
                @include('backend.partials.membershipType.formFieldsBase', ['membershipType' => null])
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
