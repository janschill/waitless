@extends('backend.layouts.default')

@section('pageTitle', 'Mitgliedschaft bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\MembershipTypeController@update', ['membershipType' => $membershipType])}}" method="POST">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $membershipType->title }}</strong>
                </legend>
                @include('backend.partials.membershipType.formFieldsBase')
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.disk')</span>
                    Speichern
                </button>
            </fieldset>
        </form>
    </article>
@endsection
