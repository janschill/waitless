@extends('backend.layouts.default')

@section('pageTitle', 'Mitglied bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    @if($member->openFee->first())
        <article class="article article--large">
            <p class="paragraph">Dieses Mitglied hat unbezahlte Mitgliedsbeiträge. Es sind noch <strong class="strong">{{ number_format($member->openFee->first()->amount - $member->openFee->first()->paid_amount, 2, ',', '.') }} Euro</strong> offen. Sollten diese Mitgliedsbeiträge bereits bezahlt sein, kannst du das jetzt markieren.</p>
            <form class="form" action="{{action('Backend\MembershipController@paid', ['member' => $member])}}" method="POST">
                {{ csrf_field() }}
                {{ method_field('PATCH') }}
                <div class="form__field">
                    <label class="form__label" for="part_payment">Art der Zahlung</label>
                    <div class="form__select-wrap">
                        <select class="form__select form__select--change-views" id="part_payment" name="part_payment" required="required">
                            <option value="0" data-view-group="payment-type" data-view-key="all" selected="selected">Gesamtzahlung</option>
                            <option value="1" data-view-group="payment-type" data-view-key="part">Teilzahlung</option>
                        </select>
                    </div>
                </div>
                <div class="form__view" data-view-group="payment-type" data-view-key="part">
                    <div class="form__field">
                        <label class="form__label" for="amount">Betrag</label>
                        <input class="form__input" id="amount" type="number" step="0.01" min="0" max="{{ $member->openFee->first()->amount - $member->openFee->first()->paid_amount }}" name="amount" value="{{ old('amount') }}" required="required">
                    </div>
                    @if ($errors->has('amount'))
                        <small class="error">{{ $errors->first('amount') }}</small>
                    @endif
                </div>
                <button type="submit" class="button button--positive">
                    <span class="button__icon">@include('default.partials.icons.euro')</span>
                    Als bezahlt markieren
                </button>
            </form>
        </article>
    @endif
    @if( (bool)$member->confirmed === false)
        <article class="article article--large">
            <p class="paragraph">{{ $member->memberable->name }} ist noch kein bestätigtes Mitglied.</p>
            <form class="form" action="{{ action('Backend\MemberController@confirm', ['member' => $member]) }}" method="POST">
                {{ csrf_field() }}
                {{ method_field('PATCH') }}
                <button class="button button--positive" type="submit">
                    <span class="button__icon">@include('default.partials.icons.check')</span>
                    Bestätigen
                </button>
            </form>
        </article>
    @endif
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberController@update', ['member' => $member]) }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $member->memberable->name }}</strong>
                </legend>
                @include('backend.partials.member.formFieldsBase')
                @include('backend.partials.member.formFieldsMemberProperties', ['memberProperties' => $club->memberProperties])
                @include('backend.partials.member.formFieldsMembershipTypes', ['membershipTypes' => $club->membershipTypes])
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.disk')</span>
                    Speichern
                </button>
            </fieldset>
        </form>
    </article>
@endsection
