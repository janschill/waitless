@extends('backend.layouts.default')

@section('pageTitle', 'Mitglieder')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h2 class="headline headline--important">
            <strong class="strong">Mitglieder</strong>
        </h2>
        @if($club->members->count() > 0)
            <section class="overview overview--searchable" data-placeholder="Suche …" data-no-rows="Keine Mitglieder gefunden. <a class='link' href='{{ action('Backend\MemberController@create') }}'>Neues Mitglied</a> erstellen." data-info="{start}–{end} von {rows} Mitglieder">
                <table class="overview__table">
                    <thead class="overview__header">
                        <tr class="overview__row">
                            <th class="overview__cell" title="Mitgliedsnummer">Mtgl.-Nr.</th>
                            <th class="overview__cell">Name</th>
                            <th class="overview__cell">E-Mail-Adresse</th>
                            <th class="overview__cell"></th>
                            <th class="overview__cell"></th>
                        </tr>
                    </thead>
                    @foreach($club->members as $member)
                        <tr class="overview__row">
                            <td class="overview__cell">
                                {{ $member->member_number }}
                            </td>
                            <td class="overview__cell">
                                {{ $member->memberable->name }}
                            </td>
                            <td class="overview__cell">
                                <a class="link" href="mailto:{{ $member->email }}">{{ $member->email }}</a>
                            </td>
                            <td class="overview__cell overview__cell--fit-to-content">
                                <a class="button button--primary button--without-text" href="{{ action('Backend\MemberController@edit', ['member' => $member]) }}">
                                    <span class="button__icon">@include('default.partials.icons.pencil')</span>
                                    Bearbeiten
                                </a>
                            </td>
                            <td class="overview__cell overview__cell--fit-to-content">
                                <a class="button button--negative button--without-text" href="{{ action('Backend\MemberController@remove', ['member' => $member]) }}">
                                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                                    Löschen
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </table>
            </section>
        @else
            <p class="paragraph">Der Verein hat keine Mitglieder.</p>
            <a class="button button--primary" href="{{ action('Backend\MemberController@create') }}">
                <span class="button__icon">@include('default.partials.icons.memberCreate')</span>
                Mitglied erstellen
            </a>
        @endif
    </article>
@endsection
