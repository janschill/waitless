@extends('backend.layouts.default')

@section('pageTitle', 'Mitglied löschen')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberController@destroy', ['member' => $member]) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $member->memberable->name }}</strong>
                </legend>
                <p class="paragraph">
                    Das Mitglied "{{ $member->memberable->name }}" jetzt löschen.
                </p>
                <button class="button button--negative" type="submit">
                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                    Löschen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
