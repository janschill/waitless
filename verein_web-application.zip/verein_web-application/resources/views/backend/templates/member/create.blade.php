@extends('backend.layouts.default')

@section('pageTitle', 'Neues Mitglied')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberController@store') }}" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="club_id" value="{{ $club->id }}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neues Mitglied</strong>
                </legend>
                @include('backend.partials.member.formFieldsBase', ['member' => null])
                @include('backend.partials.member.formFieldsMemberProperties', ['memberProperties' => $club->memberProperties, 'member' => null])
                @include('backend.partials.member.formFieldsMembershipTypes', ['membershipTypes' => $club->membershipTypes, 'member' => null])
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
