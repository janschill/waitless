@extends('backend.layouts.default')

@section('pageTitle', 'Verein löschen')
@section('mainMenu')
    @include('backend.partials.menu.settings')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\ClubController@destroy') }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $club->name }}</strong>
                </legend>
                <p class="paragraph">
                    Den Verein "{{ $club->name }}" jetzt löschen.
                </p>
                <button class="button button--negative" type="submit">
                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                    Löschen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
