@extends('backend.layouts.default')

@section('pageTitle', 'Benutzer verwalten')
@section('mainMenu')
    @include('backend.partials.menu.settings')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h2 class="headline headline--important">
            <strong class="strong">Benutzer</strong>
        </h2>
        <section class="overview">
            <table class="overview__table">
                <thead class="overview__header">
                    <tr class="overview__row">
                        <th class="overview__cell">Name</th>
                        <th class="overview__cell">E-Mail-Adresse</th>
                        <th class="overview__cell"></th>
                    </tr>
                </thead>
                @foreach($club->users as $user)
                    <tr class="overview__row">
                        <td class="overview__cell">
                            {{ $user->first_name . ' ' . $user->last_name }}
                        </td>
                        <td class="overview__cell">
                            {{ $user->email }}
                        </td>
                        <td class="overview__cell overview__cell--fit-to-content">
                            <form action="{{ action('Backend\ClubController@removeUser') }}" method="POST">
                                {{ csrf_field() }}
                                <input type="hidden" name="user" value="{{ $user->id }}">
                                <button type="submit" class="button button--negative button--without-text">
                                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                                    Vorschau
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </table>
        </section>
        @if ($errors->has('self_deleting'))
            <p class="error">{{ $errors->first('self_deleting') }}</p>
        @endif
    </article>
    <article class="article article--large">
        <form class="form" action="{{action('Backend\ClubController@storeUser')}}" method="POST">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline">
                    Benutzer hinzufügen
                </legend>
                <div class="form__field">
                    <label class="form__label" for="email">E-Mail-Adresse</label>
                    <input class="form__input" type="email" id="email" name="email" required>
                </div>
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Hinzufügen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
