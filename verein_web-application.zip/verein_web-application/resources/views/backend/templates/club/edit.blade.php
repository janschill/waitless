@extends('backend.layouts.default')

@section('pageTitle', 'Verein bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.settings')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\ClubController@update') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $club->name }}</strong>
                </legend>
                @include('backend.partials.club.formFieldsBase')
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.disk')</span>
                    Speichern
                </button>
            </fieldset>
        </form>
    </article>
@endsection
