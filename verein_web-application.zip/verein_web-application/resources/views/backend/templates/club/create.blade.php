@extends('backend.layouts.default')

@section('pageTitle', 'Neuer Verein')
@section('mainMenu')
    @include('backend.partials.menu.profile')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\ClubController@store') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neuer Verein</strong>
                </legend>
                @include('backend.partials.club.formFieldsBase', ['club' => null])
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
