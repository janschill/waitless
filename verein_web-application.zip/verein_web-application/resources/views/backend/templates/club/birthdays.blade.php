@extends('backend.layouts.default')

@section('pageTitle', 'Geburtstage')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    @if($club->getAnniversaryMembers()->count() || $club->getBirthdayOrganisations()->count())
        @if($club->getBirthdayPersons()->count())
            <h2 class="headline headline--alternative">Geburtstage</h2>
            @foreach($club->getBirthdayPersons() as $person)
                <article class="card">
                    <figure class="card__figure card__figure--secondary">
                        <span class="card__icon">
                            @include('default.partials.icons.members')
                        </span>
                    </figure>
                        <time class="card__time" datetime="{{ \Carbon\Carbon::parse($person->birthday)->format('r') }}">
                            Am {{ \Carbon\Carbon::parse($person->birthday)->format('d.m.') }}
                        </time>
                        <h4 class="headline headline--unobtrusive">Geburtstag</h4>
                        <p class="paragraph">
                            <a class="link" href="{{action('Backend\MemberController@edit', ['member' => $person->member_id])}}">{{$person->first_name . ' ' . $person->last_name}}</a> wird {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($person->birthday)->format('Y')}} Jahre alt.
                        </p>
                </article>
            @endforeach
        @endif
        @if($club->getBirthdayOrganisations()->count())
            <h2 class="headline headline--alternative">Firmengeburtstage</h2>
            @foreach($club->getBirthdayOrganisations() as $organisation)
                <article class="card">
                    <figure class="card__figure card__figure--secondary">
                        <span class="card__icon">
                            @include('default.partials.icons.members')
                        </span>
                    </figure>
                        <time class="card__time" datetime="{{ \Carbon\Carbon::parse($organisation->founded)->format('r') }}">
                            Am {{ \Carbon\Carbon::parse($organisation->founded)->format('d.m.') }}
                        </time>
                        <h4 class="headline headline--unobtrusive">Geburtstag</h4>
                        <p class="paragraph">
                            <a class="link" href="{{action('Backend\MemberController@edit', ['member' => $organisation->member_id])}}">{{$organisation->name }}</a> besteht seit {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($organisation->founded)->format('Y')}} Jahren.
                        </p>
                </article>
            @endforeach
        @endif
    @else
        <article class="article">
            <h1 class="headline headline--important">
                <strong class="strong">Geburtstage</strong>
            </h1>
            <p class="paragraph">Keine bevorstehenden Geburtstage.</p>
        </article>
    @endif
@endsection
