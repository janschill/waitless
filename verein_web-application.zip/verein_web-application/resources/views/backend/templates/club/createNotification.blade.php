@extends('backend.layouts.default')

@section('pageTitle', 'Neue Benachrichtigung')
@section('mainMenu')
    @include('backend.partials.menu.dashboard')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\ClubController@storeNotification') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neue Benachrichtigung</strong>
                </legend>
                <div class="form__field">
                    <label class="form__label" for="headline">Überschrift</label>
                    <input class="form__input" type="text" id="headline" name="headline" required>
                </div>
                <div class="form__field">
                    <label class="form__label" for="text">Text</label>
                    <input class="form__input" type="text" id="text" name="text" required>
                </div>
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
