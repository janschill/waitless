@extends('backend.layouts.default')

@section('pageTitle', 'Jubiläen')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    @if($club->getAnniversaryMembers()->count())
        @foreach($club->getAnniversaryMembers() as $member)
            <article class="card">
                <figure class="card__figure card__figure--secondary">
                    <span class="card__icon">
                        @include('default.partials.icons.members')
                    </span>
                </figure>
                    <time class="card__time" datetime="{{ \Carbon\Carbon::parse($member->member_since)->format('r') }}">
                        Am {{ \Carbon\Carbon::parse($member->member_since)->format('d.m.') }}
                    </time>
                    <h4 class="headline headline--unobtrusive">Jubiläum</h4>
                    <p class="paragraph">
                        <a class="link" href="{{action('Backend\MemberController@edit', ['member' => $member])}}">{{$member->memberable->name }}</a> ist am {{$member->member_since->format('d.m.')}} seit {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($member->member_since)->format('Y')}} Jahren im Verein.
                    </p>
            </article>
        @endforeach
    @else
        <article class="article">
            <h1 class="headline headline--important">
                <strong class="strong">Jubiläen</strong>
            </h1>
            <p class="paragraph">Keine bevorstehenden Jubiläen.</p>
        </article>
    @endif
@endsection
