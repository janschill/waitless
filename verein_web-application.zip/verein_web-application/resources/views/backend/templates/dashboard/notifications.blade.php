@extends('backend.layouts.default')

@section('pageTitle', 'Benachrichtigungen')
@section('mainMenu')
    @include('backend.partials.menu.dashboard')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Benachrichtigungen</strong>
        </h1>
    </article>
    @if($notifications)
        @foreach($notifications as $notification)
            @include('backend.partials.notification.card', ['notification' => $notification])
        @endforeach
    @else
        <p class="paragraph">Keine Benachrichtigungen</p>
    @endif
@endsection
