@extends('backend.layouts.default')

@section('pageTitle', 'Dashboard')
@section('mainMenu')
    @include('backend.partials.menu.dashboard')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <a class="headline__icon" href="{{action('Backend\ClubController@edit')}}">@include('default.partials.icons.pencil')</a>
            <strong class="strong">{{ $club->name }}</strong>
        </h1>
    </article>
    <ul class="grid">
        <li class="grid__half-first">
            <article class="article">
                <h2 class="headline">Statistiken</h2>
                <ul class="grid">
                    <li class="grid__half-first">
                        @include('backend.partials.statistics.clubMembersCount')
                    </li>
                    <li class="grid__half-second">
                        @include('backend.partials.statistics.clubLatestCreatedMembersCount')
                    </li>
                </ul>
                <a class="link" href="{{action('Backend\DashboardController@statistics')}}">
                    <span class="link__icon">@include('default.partials.icons.arrowRight')</span>Weitere Statistiken
                </a>
            </article>
            <section class="tab">
                <ul class="tab__triggers">
                    <li class="tab__trigger tab__trigger--active" data-key="todo-1">Geburtstage</li>
                    @if($club->getBirthdayOrganisations()->count())
                        <li class="tab__trigger" data-key="todo-2">Firmengeburtstage</li>
                    @endif
                    <li class="tab__trigger" data-key="todo-3">Jubiläen</li>
                </ul>
                <ul class="tab__views">
                    <li class="tab__view tab__view--active" data-key="todo-1">
                        @if($club->getBirthdayPersons()->count())
                            @foreach($club->getBirthdayPersons() as $person)
                                <article class="card">
                                    <figure class="card__figure card__figure--secondary">
                                        <span class="card__icon">
                                            @include('default.partials.icons.members')
                                        </span>
                                    </figure>
                                        <time class="card__time" datetime="{{ \Carbon\Carbon::parse($person->birthday)->format('r') }}">
                                            Am {{ \Carbon\Carbon::parse($person->birthday)->format('d.m.') }}
                                        </time>
                                        <h4 class="headline headline--unobtrusive">Geburtstag</h4>
                                        <p class="paragraph">
                                            <a class="link" href="{{action('Backend\MemberController@edit', ['member' => $person->member_id])}}">{{$person->first_name . ' ' . $person->last_name}}</a> wird {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($person->birthday)->format('Y')}} Jahre alt.
                                        </p>
                                </article>
                            @endforeach
                        @else
                            <article class="article">
                                <p class="paragraph">Keine bevorstehenden Geburtstage</p>
                            </article>
                        @endif
                    </li>
                    @if($club->getBirthdayOrganisations()->count())
                        <li class="tab__view" data-key="todo-2">
                            @foreach($club->getBirthdayOrganisations() as $organisation)
                                <article class="card">
                                    <figure class="card__figure card__figure--secondary">
                                        <span class="card__icon">
                                            @include('default.partials.icons.members')
                                        </span>
                                    </figure>
                                        <time class="card__time" datetime="{{ \Carbon\Carbon::parse($organisation->founded)->format('r') }}">
                                            Am {{ \Carbon\Carbon::parse($organisation->founded)->format('d.m.') }}
                                        </time>
                                        <h4 class="headline headline--unobtrusive">Geburtstag</h4>
                                        <p class="paragraph">
                                            <a class="link" href="{{action('Backend\MemberController@edit', ['member' => $organisation->member_id])}}">{{$organisation->name }}</a> besteht seit {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($organisation->founded)->format('Y')}} Jahren.
                                        </p>
                                </article>
                            @endforeach
                        </li>
                    @endif
                    <li class="tab__view" data-key="todo-3">
                        @if($club->getAnniversaryMembers()->count())
                            @foreach($club->getAnniversaryMembers() as $member)
                                <article class="card">
                                    <figure class="card__figure card__figure--secondary">
                                        <span class="card__icon">
                                            @include('default.partials.icons.members')
                                        </span>
                                    </figure>
                                        <time class="card__time" datetime="{{ \Carbon\Carbon::parse($member->member_since)->format('r') }}">
                                            Am {{ \Carbon\Carbon::parse($member->member_since)->format('d.m.') }}
                                        </time>
                                        <h4 class="headline headline--unobtrusive">Geburtstag</h4>
                                        <p class="paragraph">
                                            {{$member->memberable->name }} ist am {{$member->member_since->format('d.m.')}} seit {{ \Carbon\Carbon::now()->format('Y') - \Carbon\Carbon::parse($member->member_since)->format('Y')}} Jahren im Verein.
                                        </p>
                                </article>
                            @endforeach
                        @else
                            <article class="article">
                                <p class="paragraph">Keine bevorstehenden Jubiläen</p>
                            </article>
                        @endif
                    </li>
                </ul>
            </section>
        </li>
        <li class="grid__half-second">
            <h2 class="headline headline--alternative">
                <a class="headline__icon" href="{{action('Backend\DashboardController@notifications')}}">@include('default.partials.icons.arrowRight')</a>
                Benachrichtigungen
            </h2>
            @if($notifications->count())
                @foreach($notifications as $notification)
                    @include('backend.partials.notification.card', ['notification' => $notification])
                @endforeach
            @else
                <article class="article">
                    <p class="paragraph">Keine Benachrichtigungen</p>
                </article>
            @endif
        </li>
    </ul>
@endsection
