@extends('backend.layouts.default')

@section('pageTitle', 'Statistiken')
@section('mainMenu')
    @include('backend.partials.menu.dashboard')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Statistiken</strong>
        </h1>
    </article>
    <ul class="grid">
        <li class="grid__half-first">
            <article class="article article--large">
                @include('backend.partials.statistics.clubMembersCount')
            </article>
        </li>
        <li class="grid__half-second">
            <article class="article article--large">
                @include('backend.partials.statistics.clubLatestCreatedMembersCount')
            </article>
        </li>
    </ul>
    <ul class="grid">
        <li class="grid__half-first">
            <article class="article article--large">
                @include('backend.partials.statistics.clubLatestRemovedMembersCount')
            </article>
        </li>
        <li class="grid__half-second">
            <article class="article article--large">
                @include('backend.partials.statistics.clubMonthlyEarnings')
            </article>
        </li>
    </ul>
@endsection
