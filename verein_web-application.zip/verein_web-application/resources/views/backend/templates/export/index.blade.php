@extends('backend.layouts.default')

@section('pageTitle', 'Neuer Export')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\ExportController@export') }}" method="POST">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neuer Export</strong>
                </legend>
                {{-- Possible export configuration --}}
                @if($club->members->count())
                    <p class="paragraph">Export wird {{$club->members->count()}} Mitglieder enthalten</p>
                    <button class="button button--primary" type="submit">
                        <span class="button__icon">@include('default.partials.icons.out')</span>
                        Erstellen
                    </button>
                @else
                    <p class="paragraph">Keine Mitglieder</p>
                @endif
            </fieldset>
        </form>
    </article>
@endsection

