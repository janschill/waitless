@extends('backend.layouts.default')

@section('pageTitle', 'Eigenschaft bearbeiten')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{action('Backend\MemberPropertyController@update', ['memberProperty' => $memberProperty])}}" method="POST">
            {{ csrf_field() }}
            {{ method_field('PATCH') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $memberProperty->title }}</strong>
                </legend>
                @include('backend.partials.memberProperty.formFieldsBase')
                <ul class="button-list">
                    <li class="button-list__item">
                        <button class="button button--primary" type="submit">
                            <span class="button__icon">@include('default.partials.icons.disk')</span>
                            Speichern
                        </button>
                    </li>
                    <li class="button-list__item">
                        <a class="button button--negative" href="{{ action('Backend\MemberPropertyController@remove', ['memberProperty' => $memberProperty]) }}">
                            <span class="button__icon">@include('default.partials.icons.cross')</span>
                            Löschen
                        </a>
                    </li>
                </ul>
            </fieldset>
        </form>
    </article>
    @if($memberProperty->type === \VV\Verein\MemberProperty::TYPE_SELECT)
        <article class="article article--large">
            @if($memberProperty->memberPropertyValues->count())
                <h2 class="headline">Alle Eigenschaftswerte</h2>
                <ol class="list">
                    @foreach($memberProperty->memberPropertyValues as $memberPropertyValue)
                        <li class="list__item">
                            <a class="link" href="{{ action('Backend\MemberPropertyValueController@edit', ['memberPropertyValue' => $memberPropertyValue]) }}">{{ $memberPropertyValue->value }}</a>
                        </li>
                    @endforeach
                </ol>
                <hr class="divider">
            @endif
            <form class="form" action="{{action('Backend\MemberPropertyValueController@store')}}" method="POST">
                {{ csrf_field() }}
                <input type="hidden" name="member_property_id" value="{{ $memberProperty->id }}">
                <fieldset class="form__fieldset">
                    <legend class="headline">Neuer Eigenschaftswert</legend>
                    @include('backend.partials.memberPropertyValue.formFieldsBase', ['memberPropertyValue' => null])
                    <button class="button button--primary" type="submit">
                        <span class="button__icon">@include('default.partials.icons.create')</span>
                        Erstellen
                    </button>
                </fieldset>
            </form>
        </article>
    @endif
@endsection
