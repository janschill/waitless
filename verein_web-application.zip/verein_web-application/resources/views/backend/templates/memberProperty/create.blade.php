@extends('backend.layouts.default')

@section('pageTitle', 'Neue Eigenschaft')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberPropertyController@store') }}" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="club_id" value="{{ $club->id }}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neue Eigenschaft</strong>
                </legend>
                @include('backend.partials.memberProperty.formFieldsBase', ['memberProperty' => null])
                <div class="form__field form__field--select">
                    <label class="form__label" for="type">Typ</label>
                    <div class="form__select-wrap">
                        <select class="form__select" name="type" id="type" required="required">
                            <option value="{{\VV\Verein\MemberProperty::TYPE_SELECT}}">Auswahlfeld</option>
                            <option value="{{\VV\Verein\MemberProperty::TYPE_INPUT}}">Freitextfeld</option>
                        </select>
                    </div>
                </div>
                <button class="button button--primary" type="submit">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
