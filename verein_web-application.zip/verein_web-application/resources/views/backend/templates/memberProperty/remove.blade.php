@extends('backend.layouts.default')

@section('pageTitle', 'Eigenschaft löschen')
@section('mainMenu')
    @include('backend.partials.menu.members')
@endsection
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Backend\MemberPropertyController@destroy', ['memberProperty' => $memberProperty]) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">{{ $memberProperty->title }}</strong>
                </legend>
                <p class="paragraph">
                    Die Eigenschaft "{{ $memberProperty->title }}" jetzt löschen.
                </p>
                <button class="button button--negative" type="submit">
                    <span class="button__icon">@include('default.partials.icons.cross')</span>
                    Löschen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
