@extends('default.layouts.mail')

@section('subject')
    Passwort zurücksetzen
@endsection

@section('teaser')
    Passwort zurücksetzen
@endsection

@section('main')
    Du erhälst diese E-Mail, da du dein Passwort für vereinfacht zurücksetzen möchtest.<br>
    <a style="color: #888888; text-decoration: underline;" href="{{ url(config('app.url').route('password.reset', $token, false)) }}">Passwort jetzt zurücksetzen</a>
@endsection
