@extends('default.layouts.mail')

@section('subject')
    {{ $mailing->subject }}
@endsection

@section('teaser')
    {{ $mailing->subject }}
@endsection

@section('main')
    {!! nl2br(e($mailing->text)) !!}
@endsection
