<!DOCTYPE html>
<html class="html html--corporate" lang="{{ config('app.locale') }}">
    <head>
        @include('corporate.partials.head')
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('stylesheets/corporate.min.css') }}?v={{time()}}" media="all" />
    </head>
    <body class="body body--corporate">
        @include('default.partials.browseHappy')
        <main class="main-simple">
            @yield('mainContent')
            <h1 class="main-simple__logo">
                <a href="{{action('Backend\DashboardController@index')}}">
                    <img width="200" src="/images/vereinfacht.svg" alt="{{ config('app.name') }}">
                </a>
            </h1>
        </main>
        <script type="text/javascript" src="{{ URL::asset('javascripts/corporate.min.js') }}?v={{time()}}"></script>
        <script type="text/javascript" src="https://embed.small.chat/T03C9RPCZG9LGQEY0K.js" async></script>
    </body>
</html>
