@extends('default.layouts.mail')

@section('subject')
    Mitglied erstellt
@endsection

@section('teaser')
    Mitglied erstellt
@endsection

@section('main')
    {{ action('Corporate\MemberController@register', ['member' => $member, 'club' => $club]) }}
@endsection
