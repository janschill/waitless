@extends('corporate.layouts.default')

@section('pageTitle', 'Verein anlegen')
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Durchstarten</strong>
        </h1>
        <p class="paragraph">Du hast noch keinen Verein angelegt. Vielleicht möchtest du auch nur zu einem Verein hinzugefügt werden, dann melde dich bei den entsprechenden Leuten im Verein, sie können dich anhand der E-Mail-Adresse zum Verein hinzufügen. Wenn du allerdings mit einem neuen Verein durchstarten möchtest, dann fülle das Formular aus und los gehts.</p>
        <form action="{{action('Corporate\ClubController@store')}}" method="POST">
            {{ csrf_field() }}
            <fieldset class="form__fieldset">
                <div class="form__field">
                    <label class="form__label" for="name">Name</label>
                    <input class="form__input" id="name" type="text" name="name" value="{{ old('name') }}" required="required">
                </div>
                @if ($errors->has('name'))
                    <small class="error">{{ $errors->first('name') }}</small>
                @endif
                <div class="form__field">
                    <label class="form__label" for="email">E-Mail-Adresse</label>
                    <input class="form__input" id="email" type="email" name="email" value="{{ old('email') }}" required>
                </div>
                @if ($errors->has('email'))
                    <small class="error">{{ $errors->first('email') }}</small>
                @endif
                <button type="submit" class="button button--primary">
                    <span class="button__icon">@include('default.partials.icons.create')</span>
                    Erstellen
                </button>
            </fieldset>
        </form>
    </article>
@endsection
