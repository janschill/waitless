@extends('backend.layouts.default')

@section('pageTitle', 'Impressum')
@section('mainMenu')
    @include('backend.partials.menu.corporate')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Impressum</strong>
        </h1>
        <p class="paragraph">
            Inhaltlich Verantwortlich gemäß § 5 TMG
        </p>
        <p class="paragraph">
            visuellverstehen GmbH<br>
            Nordergraben 70<br>
            24937 Flensburg
        </p>
        <p class="paragraph">
            <a href="tel:+4946115065360">0461 15065360</a><br>
            <a class="link" href="https://www.visuellverstehen.de" target="_blank">www.visuellverstehen.de</a><br>
            <a class="link" href="mailto:kontakt@visuellverstehen.de">kontakt@visuellverstehen.de</a>
        </p>
        <p class="paragraph">
            Geschäftsführende Gesellschafter:<br>
            Malte Riechmann und Sören Riechmann
        </p>
        <p class="paragraph">
            Amtsgericht Flensburg<br>
            HRB 9632 FL<br>
            USt-IdNr. DE285305364
        </p>
        <p class="paragraph">Dieses Impressum gilt auch für unsere <a class="link" target="_blank" href="https://www.facebook.com/Vereinfacht-136938837139411/">Facebook-Fanpage</a>.</p>
        <hr class="divider">
        <h2 class="headline">Kontakt</h2>
        <p class="paragraph">
            vereinfacht<br>
            <a href="tel:+4946115065366">0461 15065366</a><br>
            <a class="link" href="https://vereinfacht.digital" target="_blank">vereinfacht.digital</a><br>
            <a class="link" href="mailto:hallo@vereinfacht.digital">hallo@vereinfacht.digital</a>
        </p>
    </article>
@endsection
