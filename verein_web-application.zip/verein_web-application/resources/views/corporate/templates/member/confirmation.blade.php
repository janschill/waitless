@extends('corporate.layouts.default')

@section('pageTitle', 'Anmeldung bestätigen')
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">Anmeldung bestätigen</h1>
        <p class="paragraph">E-Mail gesendet -> bestätigen</p>
    </article>
@endsection
