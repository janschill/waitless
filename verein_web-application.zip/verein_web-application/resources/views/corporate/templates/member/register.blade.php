@extends('corporate.layouts.default')

@section('pageTitle', 'Anmeldung bestätigt')
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">Anmeldung bestätigt</h1>
        <p class="paragraph">Danke</p>
    </article>
@endsection
