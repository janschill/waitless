@extends('corporate.layouts.default')

@section('pageTitle', 'Neues Mitglied')
@section('mainContent')
    <article class="article article--large">
        <form class="form" action="{{ action('Corporate\MemberController@store', ['club' => $club]) }}" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="club_id" value="{{ $club->id }}">
            <fieldset class="form__fieldset">
                <legend class="headline headline--important">
                    <strong class="strong">Neues Mitglied</strong>
                </legend>
                @include('backend.partials.member.formFieldsBase', ['member' => null])
                @include('backend.partials.member.formFieldsMemberProperties', ['memberProperties' => $club->memberProperties, 'member' => null])
                <button class="button button--primary" type="submit">Erstellen</button>
            </fieldset>
        </form>
    </article>
@endsection
