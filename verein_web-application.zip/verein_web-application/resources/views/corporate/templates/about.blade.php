@extends('backend.layouts.default')

@section('pageTitle', 'Über uns')
@section('mainMenu')
    @include('backend.partials.menu.corporate')
@endsection
@section('mainContent')
    <article class="article article--large">
        <h1 class="headline headline--important">
            <strong class="strong">Über uns</strong>
        </h1>
        <p class="paragraph">Wir bei vereinfacht sind selbst in Vereinen und Organisationen aktiv – für Dinge, die uns am Herzen liegen.</p>
        <p class="paragraph">Damit sich freiwilliges Engagement ungebremst entfaltet, haben wir vereinfacht entwickelt: Mit unserer Software unterstützen wir verschiedenste Vereine bei der Verwaltung und sorgen für fließende Arbeitsabläufe. Durch einfache Bedienung und zentrale Organisation per Smartphone, Tablet oder Computer spart ihr euch mit vereinfacht kostbare Zeit.
        <p class="paragraph">Derzeit befindet sich vereinfacht in der Beta-Phase mit überschaubaren Funktionen, die sich auf die Verwaltung von Mitgliedern (individuell an verschiedene Vereinsstrukturen angepasst) beschränken. Einfache Mailings sind auch schon möglich und es gibt einzelne Statistiken. Viele weitere Funktionen sind aber schon geplant, wir wollen diese Stück für Stück entwickeln und veröffentlichen.
        <p class="paragraph">Ihr habt Wünsche oder Verbesserungen? Wir sind offen für euer Feedback – schreibt uns (<a class="link" href="mailto:hallo@vereinfacht.digital">hallo@vereinfacht.digital</a>) oder ruft uns an (<a href="tel:+4946115065366">0461 15065366</a>).</p>
        <p class="paragraph">Übrigens: Hinter der Idee und Umsetzung von vereinfacht steckt <a class="link" href="https://www.visuellverstehen.de" target="_blank">visuellverstehen</a>. Wir sind eine Agentur für visuelle Kommunikation und digitale Anwendungen aus Flensburg. Sonst setzen wir unsere Fähigkeiten für andere Unternehmen oder Organisationen ein – diesmal schaffen wir aber unser eigenes Produkt: nach unseren Vorstellungen und Erfahrungen. Unser Anspruch ist eine hochwertige Vereinssoftware, mit eigener Handschrift in geschmackvollem Design zu entwerfen.</p>
    </article>
@endsection
