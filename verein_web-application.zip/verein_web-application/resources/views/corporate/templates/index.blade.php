@extends('corporate.layouts.default')

@section('pageTitle', 'Login')
@section('mainContent')
    @guest
        <article class="article">
            <section class="tab">
                <ul class="tab__views">
                    <li class="tab__view tab__view--active" data-key="login-signup-newsletter-0">
                        <figure class="figure figure--spacing">
                            <img class="figure__image" src="{{ URL::asset('images/icons/login.svg') }}" alt="Login">
                        </figure>
                    </li>
                    <li class="tab__view" data-key="login-signup-newsletter-1">
                        <figure class="figure figure--spacing">
                            <img class="figure__image" src="{{ URL::asset('images/icons/register.svg') }}" alt="Registrieren">
                        </figure>
                    </li>
                    <li class="tab__view" data-key="login-signup-newsletter-2">
                        <figure class="figure figure--spacing">
                            <img class="figure__image" src="{{ URL::asset('images/icons/newsletter.svg') }}" alt="Newsletter">
                        </figure>
                    </li>
                </ul>
                <ul class="tab__triggers">
                    <li class="tab__trigger tab__trigger--active" data-key="login-signup-newsletter-0">Login</li>
                    <li class="tab__trigger" data-key="login-signup-newsletter-1">Registrieren</li>
                    <li class="tab__trigger" data-key="login-signup-newsletter-2">Newsletter</li>
                </ul>
                <ul class="tab__views">
                    <li class="tab__view tab__view--active" data-key="login-signup-newsletter-0">
                        <form class="form" method="POST" action="{{ action('Backend\Auth\LoginController@login') }}">
                            {{ csrf_field() }}
                            <fieldset class="form__fieldset">
                                @include('backend.partials.auth.formFieldsLogin')
                                <ul class="button-list">
                                    <li class="button-list__item">
                                        <button class="button button--primary" type="submit">
                                            <span class="button__icon">@include('default.partials.icons.in')</span>
                                            Login
                                        </button>
                                    </li>
                                    <li class="button-list__item button-list__item--right">
                                        <a class="link link--button-spacing" href="{{ action('Backend\Auth\ForgotPasswordController@showLinkRequestForm') }}">Passwort vergessen</a>
                                    </li>
                                </ul>
                            </fieldset>
                        </form>
                    </li>
                    <li class="tab__view" data-key="login-signup-newsletter-1">
                        <form class="form" method="POST" action="{{ action('Backend\Auth\RegisterController@register') }}">
                            {{ csrf_field() }}
                            <fieldset class="form__fieldset">
                                @include('backend.partials.auth.formFieldsRegister')
                                <p class="paragraph">Wir befinden uns derzeit in einer Testphase. Eventuell setzen wir das System vor dem eigentlichen Start nochmals zurück, sodass all eure Daten verloren gehen könnten.</p>
                                <button class="button button--primary" type="submit">
                                    <span class="button__icon">@include('default.partials.icons.create')</span>
                                    Registrieren
                                </button>
                            </fieldset>
                        </form>
                    </li>
                    <li class="tab__view" data-key="login-signup-newsletter-2">
                        <form class="form" action="https://digital.us17.list-manage.com/subscribe/post?u=093b24d265261d34e3834b1b4&amp;id=8c68145d0b" method="post" name="mc-embedded-subscribe-form" target="_blank">
                            <input class="form__hidden" type="hidden" name="b_093b24d265261d34e3834b1b4_8c68145d0b" tabindex="-1" value="">
                            <fieldset class="form__fieldset">
                                <div class="form__field">
                                    <label class="form__label" for="EMAIL">E-Mail-Adresse</label>
                                    <input class="form__input" type="email" name="EMAIL" required="required">
                                </div>
                                <div class="form__field">
                                    <label class="form__label" for="FNAME">Vorname</label>
                                    <input class="form__input" type="text" name="FNAME">
                                </div>
                                <div class="form__field">
                                    <label class="form__label" for="LNAME">Nachname</label>
                                    <input class="form__input" type="text" name="LNAME">
                                </div>
                                <button class="button button--primary" type="submit">
                                    <span class="button__icon">@include('default.partials.icons.create')</span>
                                    Abonnieren
                                </button>
                            </fieldset>
                        </form>
                    </li>
                </ul>
            </section>
        </article>
    @else
        <article class="article">
            <figure class="figure figure--spacing">
                <img class="figure__image" src="{{ URL::asset('images/mask.svg') }}" alt="vereinfacht">
            </figure>
            <h1 class="headline headline--important">
                <strong class="strong">Moin {{ Auth::user()->first_name }}!</strong>
            </h1>
            <p class="paragraph">Schön, dass du wieder vorbeischaust.</p>
            <a class="button button--primary" href="{{ action('Backend\DashboardController@index') }}">
                <span class="button__icon">@include('default.partials.icons.arrowRight')</span>
                Zur App
            </a>
        </article>
    @endguest
@endsection
