<?php

return [
    'page_title' => [
        'club_index' => 'Übersicht'
    ],
    'navigation' => [
        'start' => 'Übersicht'
    ]
];
