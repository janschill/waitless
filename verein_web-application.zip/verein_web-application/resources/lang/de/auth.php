<?php

return [
    'failed' => 'Die Zugangsdaten stimmen nicht.',
    'throttle' => 'Zu oft versucht anzumelden. Bitte versuche es nochmal in :seconds Sekunden.',
    'page_title' => [
        'login' => 'Anmelden',
        'forgotten' => 'Passwort vergessen',
        'reset' => 'Passwort zurücksetzen',
    ],

];
