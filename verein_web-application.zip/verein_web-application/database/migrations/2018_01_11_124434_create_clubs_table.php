<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClubsTable extends Migration
{
    public function up()
    {
        Schema::create('clubs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->nullable(false)->unique();
            $table->string('logo')->nullable();
            $table->string('website')->nullable();
            $table->string('email')->nullable()->unique();
            $table->string('street')->nullable();
            $table->string('postal_code')->nullable();
            $table->string('city')->nullable();
            $table->date('founding_date')->nullable();
            $table->unsignedInteger('referral_id')->nullable();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('referral_id')->references('id')->on('users')->onDelete('SET NULL');
        });
    }

    public function down()
    {
        Schema::dropIfExists('clubs');
    }
}
