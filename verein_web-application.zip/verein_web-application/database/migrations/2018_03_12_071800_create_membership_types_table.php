<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMembershipTypesTable extends Migration
{
    public function up()
    {
        Schema::create('membership_types', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->nullable(false);
            $table->unsignedDecimal('monthly_fee', 7, 2)->nullable(false);
            $table->unsignedInteger('club_id')->nullable(false);
            $table->timestamps();

            $table->foreign('club_id')->references('id')->on('clubs');
        });
    }

    public function down()
    {
        Schema::dropIfExists('membership_types');
    }
}
