<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMembershipsTable extends Migration
{
    public function up()
    {
        Schema::create('memberships', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('member_id');
            $table->unsignedDecimal('additional_fee', 7, 2)->default(0.00);
            $table->unsignedInteger('accounting_period_id');
            $table->unsignedInteger('membership_type_id');
            $table->timestamps();

            $table->foreign('member_id')->references('id')->on('members');
            $table->foreign('accounting_period_id')->references('id')->on('accounting_periods');
            $table->foreign('membership_type_id')->references('id')->on('membership_types');
        });
    }

    public function down()
    {
        Schema::dropIfExists('membership');
    }
}
