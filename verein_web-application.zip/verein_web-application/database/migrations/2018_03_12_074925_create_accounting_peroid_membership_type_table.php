<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccountingPeroidMembershipTypeTable extends Migration
{
    public function up()
    {
        Schema::create('accounting_period_membership_type', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('accounting_period_id')->unsigned();
            $table->integer('membership_type_id')->unsigned();

            $table->foreign('accounting_period_id')->references('id')->on('accounting_periods');
            $table->foreign('membership_type_id')->references('id')->on('membership_types');
        });
    }

    public function down()
    {
        Schema::dropIfExists('account_period_membership_type');
    }
}
