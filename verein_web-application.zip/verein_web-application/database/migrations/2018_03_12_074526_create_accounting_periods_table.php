<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccountingPeriodsTable extends Migration
{
    public function up()
    {
        Schema::create('accounting_periods', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->nullable(false);
            $table->unsignedInteger('in_days')->nullable(false);
        });
    }

    public function down()
    {
        Schema::dropIfExists('accounting_periods');
    }
}
