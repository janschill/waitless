<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMemberPropertyValueRelationsTable extends Migration
{
    public function up()
    {
        Schema::create('member_property_value_relations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('member_id')->unsigned();
            $table->integer('member_property_value_id')->unsigned();
            $table->timestamps();

            $table->foreign('member_id')->references('id')->on('members')->onDelete('cascade');;
            $table->foreign('member_property_value_id')->references('id')->on('member_property_values')->onDelete('cascade');;
        });
    }

    public function down()
    {
        Schema::dropIfExists('member_property_value_relations');
    }
}
