<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFeesTable extends Migration
{
    public function up()
    {
        Schema::create('fees', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedDecimal('amount', 7, 2);
            $table->unsignedDecimal('paid_amount', 7, 2)->default(0.00);
            $table->date('start');
            $table->date('end');
            $table->unsignedInteger('member_id');
            $table->unsignedInteger('membership_id');

            $table->foreign('membership_id')->references('id')->on('memberships');
            $table->foreign('member_id')->references('id')->on('members');
        });
    }

    public function down()
    {
        Schema::dropIfExists('fees');
    }
}
