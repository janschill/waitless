<?php

use Illuminate\Database\Seeder;

class MembershipTypeSeeder extends Seeder
{
    public function run()
    {
        DB::table('membership_types')->insert([
            [
                'title' => 'Basis',
                'monthly_fee' => 0.00,
                'club_id' => 1,
                'created_at' => \Carbon\Carbon::now(),
                'updated_at' => \Carbon\Carbon::now(),
            ],
            [
                'title' => 'Gold',
                'monthly_fee' => 99.99,
                'club_id' => 1,
                'created_at' => \Carbon\Carbon::now(),
                'updated_at' => \Carbon\Carbon::now(),
            ]
        ]);
    }
}
