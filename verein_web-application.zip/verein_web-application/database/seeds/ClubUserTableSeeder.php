<?php

use Illuminate\Database\Seeder;

class ClubUserTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('club_user')->insert([
            'club_id' => 1,
            'user_id' => 1,
        ]);

        DB::table('club_user')->insert([
            'club_id' => 2,
            'user_id' => 1,
        ]);

        DB::table('club_user')->insert([
            'club_id' => 3,
            'user_id' => 2,
        ]);
    }
}
