<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->insert([
            'first_name' => 'Rune',
            'last_name' => 'Piper',
            'email' => 'rune.piper@visuellverstehen.de',
            'password' => bcrypt('123456'),
        ]);

        DB::table('users')->insert([
            'first_name' => 'Malte',
            'last_name' => 'Riechmann',
            'email' => 'malte.riechmann@visuellverstehen.de',
            'password' => bcrypt('123456'),
        ]);
    }
}
