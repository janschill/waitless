<?php

use Illuminate\Database\Seeder;

class AccountingPeriodsSeeder extends Seeder
{
    public function run()
    {
        DB::table('accounting_periods')->insert([
            'id' => 1,
            'title' => 'monatlich',
            'in_days' => 30
        ]);

        DB::table('accounting_periods')->insert([
            'id' => 2,
            'title' => 'quartalsweise',
            'in_days' => 91
        ]);

        DB::table('accounting_periods')->insert([
            'id' => 3,
            'title' => 'halbjährlich',
            'in_days' => 182
        ]);

        DB::table('accounting_periods')->insert([
            'id' => 4,
            'title' => 'jährlich',
            'in_days' => 365
        ]);
    }
}
