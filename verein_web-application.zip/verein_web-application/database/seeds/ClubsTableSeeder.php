<?php

use Illuminate\Database\Seeder;

class ClubsTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('clubs')->insert([
            'name' => 'visuellverstehen',
            'email' => 'kontakt@visuellverstehen.de',
        ]);

        DB::table('clubs')->insert([
            'name' => 'ASV Jarplund-Weding',
            'email' => 'kontakt@asv-jarplund-weding.de',
        ]);

        DB::table('clubs')->insert([
            'name' => 'Chaostreff Flensburg',
            'email' => 'kontakt@chaostreff-flensburg.de',
        ]);
    }
}
