<?php

use Illuminate\Database\Seeder;

class MemberPropertySeeder extends Seeder
{
    public function run()
    {
        DB::table('member_properties')->insert([
            'title' => 'Abteilung',
            'club_id' => 1,
            'type' => 1
        ]);
    }
}
