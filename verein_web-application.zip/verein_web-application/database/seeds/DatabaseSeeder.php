<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call(UsersTableSeeder::class);
        $this->call(ClubsTableSeeder::class);
        $this->call(ClubUserTableSeeder::class);
        $this->call(MemberPropertySeeder::class);
        $this->call(AccountingPeriodsSeeder::class);
        $this->call(MembershipTypeSeeder::class);
    }
}
