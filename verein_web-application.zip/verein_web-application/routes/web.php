<?php

Route::get('/', 'Corporate\ContentController@index')->name('login');
Route::get('impressum', 'Corporate\ContentController@imprint')->middleware(['auth','clubsession']);
Route::get('ueber-uns', 'Corporate\ContentController@about')->middleware(['auth','clubsession']);
// Route::get('vereine/{club}', 'Corporate\MemberController@create');
// Route::post('vereine/{club}/mitglied-erstellen', 'Corporate\MemberController@store');
// Route::get('vereine/{club}/mitglied-erstellt', 'Corporate\MemberController@confirmation');
// Route::get('vereine/{club}/bestaetigen', 'Corporate\MemberController@register');

Route::post('login', 'Backend\Auth\LoginController@login')->middleware('guest');
Route::post('logout', 'Backend\Auth\LoginController@logout');
Route::get('registrieren', 'Backend\Auth\RegisterController@showRegistrationForm');
Route::post('registrieren', 'Backend\Auth\RegisterController@register');
Route::get('passwort-zuruecksetzen', 'Backend\Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Backend\Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('password/reset/{token}', 'Backend\Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Backend\Auth\ResetPasswordController@reset');

Route::get('app/neuer-verein', 'Corporate\ClubController@create')->middleware('auth');
Route::post('app/neuer-verein/erstellen', 'Corporate\ClubController@store')->middleware('auth');

Route::group(['prefix' => 'app/', 'middleware' => ['auth','clubsession']], function() {
    Route::get('', 'Backend\DashboardController@index');
    Route::get('statistiken', 'Backend\DashboardController@statistics');
    Route::get('benachrichtigungen', 'Backend\DashboardController@notifications');
    Route::get('benachrichtigungen/neu', 'Backend\ClubController@createNotification');
    Route::post('benachrichtigungen/erstellen', 'Backend\ClubController@storeNotification');

    Route::get('profil', 'Backend\UserController@edit');
    Route::patch('profil/aktualisieren', 'Backend\UserController@update');
    Route::get('profil/entfernen', 'Backend\UserController@remove');
    Route::delete('profil/loeschen', 'Backend\UserController@destroy');

    Route::get('neu', 'Backend\ClubController@create');
    Route::post('erstellen', 'Backend\ClubController@store');
    Route::post('wechseln', 'Backend\DashboardController@switchClub');
    Route::get('einstellungen', 'Backend\ClubController@edit');
    Route::patch('aktualisieren', 'Backend\ClubController@update');
    Route::post('wiederherstellen', 'Backend\ClubController@restore');
    Route::get('entfernen', 'Backend\ClubController@remove');
    Route::delete('loeschen', 'Backend\ClubController@destroy');
    Route::get('jubilaen', 'Backend\ClubController@anniversaries');
    Route::get('geburtstage', 'Backend\ClubController@birthdays');

    Route::get('benutzer', 'Backend\ClubController@indexUser');
    Route::post('benutzer/hinzufuegen', 'Backend\ClubController@storeUser');
    Route::get('benutzer/neu', 'Backend\UserController@create');
    Route::post('benutzer/erstellen', 'Backend\UserController@store');
    Route::post('benutzer/entfernen', 'Backend\ClubController@removeUser');

    Route::get('mitglieder', 'Backend\MemberController@index');
    Route::get('mitglieder/exportieren', 'Backend\ExportController@index');
    Route::post('mitglieder/exportieren/download', 'Backend\ExportController@export');
    Route::get('mitglieder/neu', 'Backend\MemberController@create');
    Route::post('mitglieder/erstellen', 'Backend\MemberController@store');
    Route::get('mitglieder/{member}', 'Backend\MemberController@edit')->middleware('can:access,member');
    Route::patch('mitglieder/{member}/bestaetigen', 'Backend\MemberController@confirm')->middleware('can:access,member');
    Route::patch('mitglieder/{member}/aktualisieren', 'Backend\MemberController@update')->middleware('can:access,member');
    Route::get('mitglieder/{member}/entfernen', 'Backend\MemberController@remove')->middleware('can:access,member');
    Route::delete('mitglieder/{member}/loeschen', 'Backend\MemberController@destroy')->middleware('can:access,member');
    Route::patch('mitglieder/{member}/bezahlt', 'Backend\MembershipController@paid')->middleware('can:access,member');

    Route::get('mitgliedschaften/neu', 'Backend\MembershipTypeController@create');
    Route::post('mitgliedschaften/erstellen', 'Backend\MembershipTypeController@store');
    Route::get('mitgliedschaften/{membershipType}', 'Backend\MembershipTypeController@edit')->middleware('can:access,membershipType');
    Route::post('mitgliedschaften/{membershipType}/aktualisieren', 'Backend\MembershipTypeController@update')->middleware('can:access,membershipType');

    Route::get('eigenschaften/neu', 'Backend\MemberPropertyController@create');
    Route::post('eigenschaften/erstellen', 'Backend\MemberPropertyController@store');
    Route::get('eigenschaften/{memberProperty}', 'Backend\MemberPropertyController@edit')->middleware('can:access,memberProperty');
    Route::patch('eigenschaften/{memberProperty}/aktualisieren', 'Backend\MemberPropertyController@update')->middleware('can:access,memberProperty');
    Route::get('eigenschaften/{memberProperty}/entfernen', 'Backend\MemberPropertyController@remove')->middleware('can:access,memberProperty');
    Route::delete('eigenschaften/{memberProperty}/loeschen', 'Backend\MemberPropertyController@destroy')->middleware('can:access,memberProperty');

    Route::post('eigenschaftswerte/erstellen', 'Backend\MemberPropertyValueController@store');
    Route::get('eigenschaftswerte/{memberPropertyValue}', 'Backend\MemberPropertyValueController@edit')->middleware('can:access,memberPropertyValue');
    Route::patch('eigenschaftswerte/{memberPropertyValue}/aktualisieren', 'Backend\MemberPropertyValueController@update')->middleware('can:access,memberPropertyValue');
    Route::get('eigenschaftswerte/{memberPropertyValue}/entfernen', 'Backend\MemberPropertyValueController@remove')->middleware('can:access,memberPropertyValue');
    Route::delete('eigenschaftswerte/{memberPropertyValue}/loeschen', 'Backend\MemberPropertyValueController@destroy')->middleware('can:access,memberPropertyValue');

    Route::get('mailing', 'Backend\MailingController@index');
    Route::get('mailing/neu', 'Backend\MailingController@create');
    Route::post('mailing/erstellen', 'Backend\MailingController@store');
    Route::get('mailing/{mailing}', 'Backend\MailingController@show')->middleware('can:access,mailing');
    Route::get('mailing/{mailing}/vorschau', 'Backend\MailingController@preview')->middleware('can:access,mailing');
});
